﻿
namespace UĞUR_PAZARLAMA
{
    partial class FrmIstatistikler
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmIstatistikler));
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.sidePanel1 = new DevExpress.XtraEditors.SidePanel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.LblToplamUrun = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.sidePanel2 = new DevExpress.XtraEditors.SidePanel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.LblToplamPersonel = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.sidePanel3 = new DevExpress.XtraEditors.SidePanel();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.LblToplamMusteri = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.sidePanel4 = new DevExpress.XtraEditors.SidePanel();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.LblToplamKategori = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.sidePanel5 = new DevExpress.XtraEditors.SidePanel();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.LblEnUcuzUrun = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.sidePanel6 = new DevExpress.XtraEditors.SidePanel();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.LblEnPahalıUrun = new DevExpress.XtraEditors.LabelControl();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.sidePanel7 = new DevExpress.XtraEditors.SidePanel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.LblToplamSatis = new DevExpress.XtraEditors.LabelControl();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.sidePanel8 = new DevExpress.XtraEditors.SidePanel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.LblToplamMarka = new DevExpress.XtraEditors.LabelControl();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.sidePanel9 = new DevExpress.XtraEditors.SidePanel();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.LblKritikSeviye = new DevExpress.XtraEditors.LabelControl();
            this.labelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.sidePanel10 = new DevExpress.XtraEditors.SidePanel();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.LblToplamStok = new DevExpress.XtraEditors.LabelControl();
            this.labelControl20 = new DevExpress.XtraEditors.LabelControl();
            this.sidePanel11 = new DevExpress.XtraEditors.SidePanel();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.LblEnsonSaturun = new DevExpress.XtraEditors.LabelControl();
            this.labelControl22 = new DevExpress.XtraEditors.LabelControl();
            this.sidePanel12 = new DevExpress.XtraEditors.SidePanel();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.LblEnsonurun = new DevExpress.XtraEditors.LabelControl();
            this.labelControl24 = new DevExpress.XtraEditors.LabelControl();
            this.sidePanel13 = new DevExpress.XtraEditors.SidePanel();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.LblKasa = new DevExpress.XtraEditors.LabelControl();
            this.labelControl26 = new DevExpress.XtraEditors.LabelControl();
            this.sidePanel14 = new DevExpress.XtraEditors.SidePanel();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.LblToplamAlimTutar = new DevExpress.XtraEditors.LabelControl();
            this.labelControl28 = new DevExpress.XtraEditors.LabelControl();
            this.sidePanel15 = new DevExpress.XtraEditors.SidePanel();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.LblToplamAlim = new DevExpress.XtraEditors.LabelControl();
            this.labelControl30 = new DevExpress.XtraEditors.LabelControl();
            this.sidePanel16 = new DevExpress.XtraEditors.SidePanel();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.LblKaçFarkliil = new DevExpress.XtraEditors.LabelControl();
            this.labelControl32 = new DevExpress.XtraEditors.LabelControl();
            this.sidePanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.sidePanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.sidePanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.sidePanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.sidePanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.sidePanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.sidePanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.sidePanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.sidePanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            this.sidePanel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            this.sidePanel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            this.sidePanel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            this.sidePanel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.sidePanel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.sidePanel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            this.sidePanel16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            this.SuspendLayout();
            // 
            // simpleButton1
            // 
            this.simpleButton1.Appearance.BackColor = System.Drawing.Color.OrangeRed;
            this.simpleButton1.Appearance.Options.UseBackColor = true;
            this.simpleButton1.Location = new System.Drawing.Point(1056, 0);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.Size = new System.Drawing.Size(38, 23);
            this.simpleButton1.TabIndex = 16;
            this.simpleButton1.Click += new System.EventHandler(this.simpleButton1_Click);
            // 
            // sidePanel1
            // 
            this.sidePanel1.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(189)))), ((int)(((byte)(50)))));
            this.sidePanel1.Appearance.Options.UseBackColor = true;
            this.sidePanel1.Controls.Add(this.pictureBox1);
            this.sidePanel1.Controls.Add(this.LblToplamUrun);
            this.sidePanel1.Controls.Add(this.labelControl2);
            this.sidePanel1.Location = new System.Drawing.Point(37, 24);
            this.sidePanel1.Name = "sidePanel1";
            this.sidePanel1.Size = new System.Drawing.Size(250, 130);
            this.sidePanel1.TabIndex = 17;
            this.sidePanel1.Text = "sidePanel1";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(158, 63);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 33;
            this.pictureBox1.TabStop = false;
            // 
            // LblToplamUrun
            // 
            this.LblToplamUrun.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblToplamUrun.Appearance.Options.UseFont = true;
            this.LblToplamUrun.Location = new System.Drawing.Point(51, 78);
            this.LblToplamUrun.Name = "LblToplamUrun";
            this.LblToplamUrun.Size = new System.Drawing.Size(11, 25);
            this.LblToplamUrun.TabIndex = 5;
            this.LblToplamUrun.Text = "0";
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl2.Appearance.Options.UseFont = true;
            this.labelControl2.Location = new System.Drawing.Point(27, 18);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(181, 25);
            this.labelControl2.TabIndex = 3;
            this.labelControl2.Text = "Toplam Ürün Sayısı";
            // 
            // sidePanel2
            // 
            this.sidePanel2.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(177)))), ((int)(((byte)(44)))));
            this.sidePanel2.Appearance.Options.UseBackColor = true;
            this.sidePanel2.Controls.Add(this.pictureBox4);
            this.sidePanel2.Controls.Add(this.LblToplamPersonel);
            this.sidePanel2.Controls.Add(this.labelControl4);
            this.sidePanel2.Location = new System.Drawing.Point(293, 24);
            this.sidePanel2.Name = "sidePanel2";
            this.sidePanel2.Size = new System.Drawing.Size(250, 130);
            this.sidePanel2.TabIndex = 18;
            this.sidePanel2.Text = "sidePanel2";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(158, 63);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(50, 50);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 46;
            this.pictureBox4.TabStop = false;
            // 
            // LblToplamPersonel
            // 
            this.LblToplamPersonel.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblToplamPersonel.Appearance.Options.UseFont = true;
            this.LblToplamPersonel.Location = new System.Drawing.Point(51, 78);
            this.LblToplamPersonel.Name = "LblToplamPersonel";
            this.LblToplamPersonel.Size = new System.Drawing.Size(11, 25);
            this.LblToplamPersonel.TabIndex = 5;
            this.LblToplamPersonel.Text = "0";
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl4.Appearance.Options.UseFont = true;
            this.labelControl4.Location = new System.Drawing.Point(27, 18);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(214, 25);
            this.labelControl4.TabIndex = 3;
            this.labelControl4.Text = "Toplam Personel Sayısı";
            // 
            // sidePanel3
            // 
            this.sidePanel3.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(54)))), ((int)(((byte)(22)))));
            this.sidePanel3.Appearance.Options.UseBackColor = true;
            this.sidePanel3.Controls.Add(this.pictureBox7);
            this.sidePanel3.Controls.Add(this.LblToplamMusteri);
            this.sidePanel3.Controls.Add(this.labelControl6);
            this.sidePanel3.Location = new System.Drawing.Point(549, 24);
            this.sidePanel3.Name = "sidePanel3";
            this.sidePanel3.Size = new System.Drawing.Size(250, 130);
            this.sidePanel3.TabIndex = 19;
            this.sidePanel3.Text = "sidePanel3";
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(158, 63);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(50, 50);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 47;
            this.pictureBox7.TabStop = false;
            // 
            // LblToplamMusteri
            // 
            this.LblToplamMusteri.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblToplamMusteri.Appearance.Options.UseFont = true;
            this.LblToplamMusteri.Location = new System.Drawing.Point(51, 78);
            this.LblToplamMusteri.Name = "LblToplamMusteri";
            this.LblToplamMusteri.Size = new System.Drawing.Size(11, 25);
            this.LblToplamMusteri.TabIndex = 5;
            this.LblToplamMusteri.Text = "0";
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl6.Appearance.Options.UseFont = true;
            this.labelControl6.Location = new System.Drawing.Point(27, 18);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(203, 25);
            this.labelControl6.TabIndex = 3;
            this.labelControl6.Text = "Toplam Müşteri Sayısı";
            // 
            // sidePanel4
            // 
            this.sidePanel4.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(151)))), ((int)(((byte)(230)))));
            this.sidePanel4.Appearance.Options.UseBackColor = true;
            this.sidePanel4.Controls.Add(this.pictureBox8);
            this.sidePanel4.Controls.Add(this.LblToplamKategori);
            this.sidePanel4.Controls.Add(this.labelControl8);
            this.sidePanel4.Location = new System.Drawing.Point(805, 24);
            this.sidePanel4.Name = "sidePanel4";
            this.sidePanel4.Size = new System.Drawing.Size(250, 130);
            this.sidePanel4.TabIndex = 20;
            this.sidePanel4.Text = "sidePanel4";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(158, 63);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(50, 50);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 48;
            this.pictureBox8.TabStop = false;
            // 
            // LblToplamKategori
            // 
            this.LblToplamKategori.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblToplamKategori.Appearance.Options.UseFont = true;
            this.LblToplamKategori.Location = new System.Drawing.Point(51, 78);
            this.LblToplamKategori.Name = "LblToplamKategori";
            this.LblToplamKategori.Size = new System.Drawing.Size(11, 25);
            this.LblToplamKategori.TabIndex = 5;
            this.LblToplamKategori.Text = "0";
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl8.Appearance.Options.UseFont = true;
            this.labelControl8.Location = new System.Drawing.Point(27, 18);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(212, 25);
            this.labelControl8.TabIndex = 3;
            this.labelControl8.Text = "Toplam Kategori Sayısı";
            // 
            // sidePanel5
            // 
            this.sidePanel5.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(151)))), ((int)(((byte)(230)))));
            this.sidePanel5.Appearance.Options.UseBackColor = true;
            this.sidePanel5.Controls.Add(this.pictureBox5);
            this.sidePanel5.Controls.Add(this.LblEnUcuzUrun);
            this.sidePanel5.Controls.Add(this.labelControl10);
            this.sidePanel5.Location = new System.Drawing.Point(805, 160);
            this.sidePanel5.Name = "sidePanel5";
            this.sidePanel5.Size = new System.Drawing.Size(250, 130);
            this.sidePanel5.TabIndex = 24;
            this.sidePanel5.Text = "sidePanel5";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(158, 62);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(50, 50);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 35;
            this.pictureBox5.TabStop = false;
            // 
            // LblEnUcuzUrun
            // 
            this.LblEnUcuzUrun.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblEnUcuzUrun.Appearance.Options.UseFont = true;
            this.LblEnUcuzUrun.Location = new System.Drawing.Point(12, 78);
            this.LblEnUcuzUrun.Name = "LblEnUcuzUrun";
            this.LblEnUcuzUrun.Size = new System.Drawing.Size(9, 19);
            this.LblEnUcuzUrun.TabIndex = 5;
            this.LblEnUcuzUrun.Text = "0";
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl10.Appearance.Options.UseFont = true;
            this.labelControl10.Location = new System.Drawing.Point(27, 18);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(129, 25);
            this.labelControl10.TabIndex = 3;
            this.labelControl10.Text = "En Ucuz Ürün";
            // 
            // sidePanel6
            // 
            this.sidePanel6.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(54)))), ((int)(((byte)(22)))));
            this.sidePanel6.Appearance.Options.UseBackColor = true;
            this.sidePanel6.Controls.Add(this.pictureBox6);
            this.sidePanel6.Controls.Add(this.LblEnPahalıUrun);
            this.sidePanel6.Controls.Add(this.labelControl12);
            this.sidePanel6.Location = new System.Drawing.Point(549, 160);
            this.sidePanel6.Name = "sidePanel6";
            this.sidePanel6.Size = new System.Drawing.Size(250, 130);
            this.sidePanel6.TabIndex = 23;
            this.sidePanel6.Text = "sidePanel6";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(158, 53);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(50, 50);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 34;
            this.pictureBox6.TabStop = false;
            // 
            // LblEnPahalıUrun
            // 
            this.LblEnPahalıUrun.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblEnPahalıUrun.Appearance.Options.UseFont = true;
            this.LblEnPahalıUrun.Location = new System.Drawing.Point(3, 78);
            this.LblEnPahalıUrun.Name = "LblEnPahalıUrun";
            this.LblEnPahalıUrun.Size = new System.Drawing.Size(9, 19);
            this.LblEnPahalıUrun.TabIndex = 5;
            this.LblEnPahalıUrun.Text = "0";
            // 
            // labelControl12
            // 
            this.labelControl12.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl12.Appearance.Options.UseFont = true;
            this.labelControl12.Location = new System.Drawing.Point(27, 18);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(146, 25);
            this.labelControl12.TabIndex = 3;
            this.labelControl12.Text = "Em Pahalı Ürün";
            // 
            // sidePanel7
            // 
            this.sidePanel7.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(177)))), ((int)(((byte)(44)))));
            this.sidePanel7.Appearance.Options.UseBackColor = true;
            this.sidePanel7.Controls.Add(this.pictureBox2);
            this.sidePanel7.Controls.Add(this.LblToplamSatis);
            this.sidePanel7.Controls.Add(this.labelControl14);
            this.sidePanel7.Location = new System.Drawing.Point(293, 160);
            this.sidePanel7.Name = "sidePanel7";
            this.sidePanel7.Size = new System.Drawing.Size(250, 130);
            this.sidePanel7.TabIndex = 22;
            this.sidePanel7.Text = "sidePanel7";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(158, 62);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(50, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 45;
            this.pictureBox2.TabStop = false;
            // 
            // LblToplamSatis
            // 
            this.LblToplamSatis.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblToplamSatis.Appearance.Options.UseFont = true;
            this.LblToplamSatis.Location = new System.Drawing.Point(51, 78);
            this.LblToplamSatis.Name = "LblToplamSatis";
            this.LblToplamSatis.Size = new System.Drawing.Size(11, 25);
            this.LblToplamSatis.TabIndex = 5;
            this.LblToplamSatis.Text = "0";
            // 
            // labelControl14
            // 
            this.labelControl14.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl14.Appearance.Options.UseFont = true;
            this.labelControl14.Location = new System.Drawing.Point(27, 18);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(179, 25);
            this.labelControl14.TabIndex = 3;
            this.labelControl14.Text = "Toplam Satış Sayısı";
            // 
            // sidePanel8
            // 
            this.sidePanel8.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(189)))), ((int)(((byte)(50)))));
            this.sidePanel8.Appearance.Options.UseBackColor = true;
            this.sidePanel8.Controls.Add(this.pictureBox3);
            this.sidePanel8.Controls.Add(this.LblToplamMarka);
            this.sidePanel8.Controls.Add(this.labelControl16);
            this.sidePanel8.Location = new System.Drawing.Point(37, 160);
            this.sidePanel8.Name = "sidePanel8";
            this.sidePanel8.Size = new System.Drawing.Size(250, 130);
            this.sidePanel8.TabIndex = 21;
            this.sidePanel8.Text = "sidePanel8";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(158, 53);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(50, 50);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 44;
            this.pictureBox3.TabStop = false;
            // 
            // LblToplamMarka
            // 
            this.LblToplamMarka.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblToplamMarka.Appearance.Options.UseFont = true;
            this.LblToplamMarka.Location = new System.Drawing.Point(51, 78);
            this.LblToplamMarka.Name = "LblToplamMarka";
            this.LblToplamMarka.Size = new System.Drawing.Size(11, 25);
            this.LblToplamMarka.TabIndex = 5;
            this.LblToplamMarka.Text = "0";
            // 
            // labelControl16
            // 
            this.labelControl16.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl16.Appearance.Options.UseFont = true;
            this.labelControl16.Location = new System.Drawing.Point(27, 18);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(191, 25);
            this.labelControl16.TabIndex = 3;
            this.labelControl16.Text = "Toplam Marka Sayısı";
            // 
            // sidePanel9
            // 
            this.sidePanel9.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(151)))), ((int)(((byte)(230)))));
            this.sidePanel9.Appearance.Options.UseBackColor = true;
            this.sidePanel9.Controls.Add(this.pictureBox13);
            this.sidePanel9.Controls.Add(this.LblKritikSeviye);
            this.sidePanel9.Controls.Add(this.labelControl18);
            this.sidePanel9.Location = new System.Drawing.Point(805, 296);
            this.sidePanel9.Name = "sidePanel9";
            this.sidePanel9.Size = new System.Drawing.Size(250, 130);
            this.sidePanel9.TabIndex = 28;
            this.sidePanel9.Text = "sidePanel9";
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.Location = new System.Drawing.Point(158, 53);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(50, 50);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 39;
            this.pictureBox13.TabStop = false;
            // 
            // LblKritikSeviye
            // 
            this.LblKritikSeviye.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblKritikSeviye.Appearance.Options.UseFont = true;
            this.LblKritikSeviye.Location = new System.Drawing.Point(51, 78);
            this.LblKritikSeviye.Name = "LblKritikSeviye";
            this.LblKritikSeviye.Size = new System.Drawing.Size(11, 25);
            this.LblKritikSeviye.TabIndex = 5;
            this.LblKritikSeviye.Text = "0";
            // 
            // labelControl18
            // 
            this.labelControl18.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl18.Appearance.Options.UseFont = true;
            this.labelControl18.Location = new System.Drawing.Point(12, 18);
            this.labelControl18.Name = "labelControl18";
            this.labelControl18.Size = new System.Drawing.Size(235, 19);
            this.labelControl18.TabIndex = 3;
            this.labelControl18.Text = "Kritik Seviyedeki Ürün Sayısı (15)";
            // 
            // sidePanel10
            // 
            this.sidePanel10.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(54)))), ((int)(((byte)(22)))));
            this.sidePanel10.Appearance.Options.UseBackColor = true;
            this.sidePanel10.Controls.Add(this.pictureBox14);
            this.sidePanel10.Controls.Add(this.LblToplamStok);
            this.sidePanel10.Controls.Add(this.labelControl20);
            this.sidePanel10.Location = new System.Drawing.Point(549, 296);
            this.sidePanel10.Name = "sidePanel10";
            this.sidePanel10.Size = new System.Drawing.Size(250, 130);
            this.sidePanel10.TabIndex = 27;
            this.sidePanel10.Text = "sidePanel10";
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox14.Image")));
            this.pictureBox14.Location = new System.Drawing.Point(158, 53);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(50, 50);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 38;
            this.pictureBox14.TabStop = false;
            // 
            // LblToplamStok
            // 
            this.LblToplamStok.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblToplamStok.Appearance.Options.UseFont = true;
            this.LblToplamStok.Location = new System.Drawing.Point(51, 78);
            this.LblToplamStok.Name = "LblToplamStok";
            this.LblToplamStok.Size = new System.Drawing.Size(11, 25);
            this.LblToplamStok.TabIndex = 5;
            this.LblToplamStok.Text = "0";
            // 
            // labelControl20
            // 
            this.labelControl20.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl20.Appearance.Options.UseFont = true;
            this.labelControl20.Location = new System.Drawing.Point(27, 18);
            this.labelControl20.Name = "labelControl20";
            this.labelControl20.Size = new System.Drawing.Size(175, 25);
            this.labelControl20.TabIndex = 3;
            this.labelControl20.Text = "Toplam Stok Sayısı";
            // 
            // sidePanel11
            // 
            this.sidePanel11.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(177)))), ((int)(((byte)(44)))));
            this.sidePanel11.Appearance.Options.UseBackColor = true;
            this.sidePanel11.Controls.Add(this.pictureBox15);
            this.sidePanel11.Controls.Add(this.LblEnsonSaturun);
            this.sidePanel11.Controls.Add(this.labelControl22);
            this.sidePanel11.Location = new System.Drawing.Point(293, 296);
            this.sidePanel11.Name = "sidePanel11";
            this.sidePanel11.Size = new System.Drawing.Size(250, 130);
            this.sidePanel11.TabIndex = 26;
            this.sidePanel11.Text = "sidePanel11";
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox15.Image")));
            this.pictureBox15.Location = new System.Drawing.Point(158, 53);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(50, 50);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 37;
            this.pictureBox15.TabStop = false;
            // 
            // LblEnsonSaturun
            // 
            this.LblEnsonSaturun.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblEnsonSaturun.Appearance.Options.UseFont = true;
            this.LblEnsonSaturun.Location = new System.Drawing.Point(16, 78);
            this.LblEnsonSaturun.Name = "LblEnsonSaturun";
            this.LblEnsonSaturun.Size = new System.Drawing.Size(9, 19);
            this.LblEnsonSaturun.TabIndex = 5;
            this.LblEnsonSaturun.Text = "0";
            // 
            // labelControl22
            // 
            this.labelControl22.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl22.Appearance.Options.UseFont = true;
            this.labelControl22.Location = new System.Drawing.Point(27, 18);
            this.labelControl22.Name = "labelControl22";
            this.labelControl22.Size = new System.Drawing.Size(189, 25);
            this.labelControl22.TabIndex = 3;
            this.labelControl22.Text = "En Son Satılan Ürün";
            // 
            // sidePanel12
            // 
            this.sidePanel12.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(189)))), ((int)(((byte)(50)))));
            this.sidePanel12.Appearance.Options.UseBackColor = true;
            this.sidePanel12.Controls.Add(this.pictureBox16);
            this.sidePanel12.Controls.Add(this.LblEnsonurun);
            this.sidePanel12.Controls.Add(this.labelControl24);
            this.sidePanel12.Location = new System.Drawing.Point(37, 296);
            this.sidePanel12.Name = "sidePanel12";
            this.sidePanel12.Size = new System.Drawing.Size(250, 130);
            this.sidePanel12.TabIndex = 25;
            this.sidePanel12.Text = "sidePanel12";
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox16.Image")));
            this.pictureBox16.Location = new System.Drawing.Point(158, 53);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(50, 50);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 36;
            this.pictureBox16.TabStop = false;
            // 
            // LblEnsonurun
            // 
            this.LblEnsonurun.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblEnsonurun.Appearance.Options.UseFont = true;
            this.LblEnsonurun.Location = new System.Drawing.Point(27, 78);
            this.LblEnsonurun.Name = "LblEnsonurun";
            this.LblEnsonurun.Size = new System.Drawing.Size(9, 19);
            this.LblEnsonurun.TabIndex = 5;
            this.LblEnsonurun.Text = "0";
            // 
            // labelControl24
            // 
            this.labelControl24.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl24.Appearance.Options.UseFont = true;
            this.labelControl24.Location = new System.Drawing.Point(27, 18);
            this.labelControl24.Name = "labelControl24";
            this.labelControl24.Size = new System.Drawing.Size(184, 25);
            this.labelControl24.TabIndex = 3;
            this.labelControl24.Text = "En Son Alınan Ürün";
            // 
            // sidePanel13
            // 
            this.sidePanel13.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(151)))), ((int)(((byte)(230)))));
            this.sidePanel13.Appearance.Options.UseBackColor = true;
            this.sidePanel13.Controls.Add(this.pictureBox9);
            this.sidePanel13.Controls.Add(this.LblKasa);
            this.sidePanel13.Controls.Add(this.labelControl26);
            this.sidePanel13.Location = new System.Drawing.Point(805, 432);
            this.sidePanel13.Name = "sidePanel13";
            this.sidePanel13.Size = new System.Drawing.Size(250, 130);
            this.sidePanel13.TabIndex = 32;
            this.sidePanel13.Text = "sidePanel13";
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(158, 53);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(50, 50);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 43;
            this.pictureBox9.TabStop = false;
            // 
            // LblKasa
            // 
            this.LblKasa.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblKasa.Appearance.Options.UseFont = true;
            this.LblKasa.Location = new System.Drawing.Point(51, 78);
            this.LblKasa.Name = "LblKasa";
            this.LblKasa.Size = new System.Drawing.Size(11, 25);
            this.LblKasa.TabIndex = 5;
            this.LblKasa.Text = "0";
            // 
            // labelControl26
            // 
            this.labelControl26.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl26.Appearance.Options.UseFont = true;
            this.labelControl26.Location = new System.Drawing.Point(95, 18);
            this.labelControl26.Name = "labelControl26";
            this.labelControl26.Size = new System.Drawing.Size(51, 25);
            this.labelControl26.TabIndex = 3;
            this.labelControl26.Text = "KASA";
            // 
            // sidePanel14
            // 
            this.sidePanel14.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(54)))), ((int)(((byte)(22)))));
            this.sidePanel14.Appearance.Options.UseBackColor = true;
            this.sidePanel14.Controls.Add(this.pictureBox10);
            this.sidePanel14.Controls.Add(this.LblToplamAlimTutar);
            this.sidePanel14.Controls.Add(this.labelControl28);
            this.sidePanel14.Location = new System.Drawing.Point(549, 432);
            this.sidePanel14.Name = "sidePanel14";
            this.sidePanel14.Size = new System.Drawing.Size(250, 130);
            this.sidePanel14.TabIndex = 31;
            this.sidePanel14.Text = "sidePanel14";
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(144, 53);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(64, 64);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox10.TabIndex = 42;
            this.pictureBox10.TabStop = false;
            // 
            // LblToplamAlimTutar
            // 
            this.LblToplamAlimTutar.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblToplamAlimTutar.Appearance.Options.UseFont = true;
            this.LblToplamAlimTutar.Location = new System.Drawing.Point(51, 78);
            this.LblToplamAlimTutar.Name = "LblToplamAlimTutar";
            this.LblToplamAlimTutar.Size = new System.Drawing.Size(11, 25);
            this.LblToplamAlimTutar.TabIndex = 5;
            this.LblToplamAlimTutar.Text = "0";
            // 
            // labelControl28
            // 
            this.labelControl28.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl28.Appearance.Options.UseFont = true;
            this.labelControl28.Location = new System.Drawing.Point(15, 18);
            this.labelControl28.Name = "labelControl28";
            this.labelControl28.Size = new System.Drawing.Size(232, 25);
            this.labelControl28.TabIndex = 3;
            this.labelControl28.Text = "Ürün Alımı Toplam Tutar";
            // 
            // sidePanel15
            // 
            this.sidePanel15.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(177)))), ((int)(((byte)(44)))));
            this.sidePanel15.Appearance.Options.UseBackColor = true;
            this.sidePanel15.Controls.Add(this.pictureBox11);
            this.sidePanel15.Controls.Add(this.LblToplamAlim);
            this.sidePanel15.Controls.Add(this.labelControl30);
            this.sidePanel15.Location = new System.Drawing.Point(293, 432);
            this.sidePanel15.Name = "sidePanel15";
            this.sidePanel15.Size = new System.Drawing.Size(250, 130);
            this.sidePanel15.TabIndex = 30;
            this.sidePanel15.Text = "sidePanel15";
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.Location = new System.Drawing.Point(158, 53);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(50, 50);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 41;
            this.pictureBox11.TabStop = false;
            // 
            // LblToplamAlim
            // 
            this.LblToplamAlim.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblToplamAlim.Appearance.Options.UseFont = true;
            this.LblToplamAlim.Location = new System.Drawing.Point(51, 78);
            this.LblToplamAlim.Name = "LblToplamAlim";
            this.LblToplamAlim.Size = new System.Drawing.Size(11, 25);
            this.LblToplamAlim.TabIndex = 5;
            this.LblToplamAlim.Text = "0";
            // 
            // labelControl30
            // 
            this.labelControl30.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl30.Appearance.Options.UseFont = true;
            this.labelControl30.Location = new System.Drawing.Point(27, 18);
            this.labelControl30.Name = "labelControl30";
            this.labelControl30.Size = new System.Drawing.Size(176, 25);
            this.labelControl30.TabIndex = 3;
            this.labelControl30.Text = "Toplam Alım Sayısı";
            // 
            // sidePanel16
            // 
            this.sidePanel16.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(189)))), ((int)(((byte)(50)))));
            this.sidePanel16.Appearance.Options.UseBackColor = true;
            this.sidePanel16.Controls.Add(this.pictureBox12);
            this.sidePanel16.Controls.Add(this.LblKaçFarkliil);
            this.sidePanel16.Controls.Add(this.labelControl32);
            this.sidePanel16.Location = new System.Drawing.Point(37, 432);
            this.sidePanel16.Name = "sidePanel16";
            this.sidePanel16.Size = new System.Drawing.Size(250, 130);
            this.sidePanel16.TabIndex = 29;
            this.sidePanel16.Text = "sidePanel16";
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox12.Image")));
            this.pictureBox12.Location = new System.Drawing.Point(158, 53);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(50, 50);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 40;
            this.pictureBox12.TabStop = false;
            // 
            // LblKaçFarkliil
            // 
            this.LblKaçFarkliil.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblKaçFarkliil.Appearance.Options.UseFont = true;
            this.LblKaçFarkliil.Location = new System.Drawing.Point(51, 78);
            this.LblKaçFarkliil.Name = "LblKaçFarkliil";
            this.LblKaçFarkliil.Size = new System.Drawing.Size(11, 25);
            this.LblKaçFarkliil.TabIndex = 5;
            this.LblKaçFarkliil.Text = "0";
            // 
            // labelControl32
            // 
            this.labelControl32.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl32.Appearance.Options.UseFont = true;
            this.labelControl32.Location = new System.Drawing.Point(27, 18);
            this.labelControl32.Name = "labelControl32";
            this.labelControl32.Size = new System.Drawing.Size(110, 25);
            this.labelControl32.TabIndex = 3;
            this.labelControl32.Text = "Kaç Farklı İl";
            // 
            // FrmIstatistikler
            // 
            this.Appearance.BackColor = System.Drawing.Color.OrangeRed;
            this.Appearance.Options.UseBackColor = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1093, 584);
            this.Controls.Add(this.sidePanel13);
            this.Controls.Add(this.sidePanel14);
            this.Controls.Add(this.sidePanel15);
            this.Controls.Add(this.sidePanel16);
            this.Controls.Add(this.sidePanel9);
            this.Controls.Add(this.sidePanel10);
            this.Controls.Add(this.sidePanel11);
            this.Controls.Add(this.sidePanel12);
            this.Controls.Add(this.sidePanel5);
            this.Controls.Add(this.sidePanel6);
            this.Controls.Add(this.sidePanel7);
            this.Controls.Add(this.sidePanel8);
            this.Controls.Add(this.sidePanel4);
            this.Controls.Add(this.sidePanel3);
            this.Controls.Add(this.sidePanel2);
            this.Controls.Add(this.sidePanel1);
            this.Controls.Add(this.simpleButton1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmIstatistikler";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmIstatistikler";
            this.Load += new System.EventHandler(this.FrmIstatistikler_Load);
            this.sidePanel1.ResumeLayout(false);
            this.sidePanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.sidePanel2.ResumeLayout(false);
            this.sidePanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.sidePanel3.ResumeLayout(false);
            this.sidePanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.sidePanel4.ResumeLayout(false);
            this.sidePanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.sidePanel5.ResumeLayout(false);
            this.sidePanel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.sidePanel6.ResumeLayout(false);
            this.sidePanel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.sidePanel7.ResumeLayout(false);
            this.sidePanel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.sidePanel8.ResumeLayout(false);
            this.sidePanel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.sidePanel9.ResumeLayout(false);
            this.sidePanel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            this.sidePanel10.ResumeLayout(false);
            this.sidePanel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            this.sidePanel11.ResumeLayout(false);
            this.sidePanel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            this.sidePanel12.ResumeLayout(false);
            this.sidePanel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            this.sidePanel13.ResumeLayout(false);
            this.sidePanel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.sidePanel14.ResumeLayout(false);
            this.sidePanel14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.sidePanel15.ResumeLayout(false);
            this.sidePanel15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            this.sidePanel16.ResumeLayout(false);
            this.sidePanel16.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        private DevExpress.XtraEditors.SidePanel sidePanel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private DevExpress.XtraEditors.LabelControl LblToplamUrun;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.SidePanel sidePanel2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private DevExpress.XtraEditors.LabelControl LblToplamPersonel;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.SidePanel sidePanel3;
        private System.Windows.Forms.PictureBox pictureBox7;
        private DevExpress.XtraEditors.LabelControl LblToplamMusteri;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.SidePanel sidePanel4;
        private System.Windows.Forms.PictureBox pictureBox8;
        private DevExpress.XtraEditors.LabelControl LblToplamKategori;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.SidePanel sidePanel5;
        private System.Windows.Forms.PictureBox pictureBox5;
        private DevExpress.XtraEditors.LabelControl LblEnUcuzUrun;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.SidePanel sidePanel6;
        private System.Windows.Forms.PictureBox pictureBox6;
        private DevExpress.XtraEditors.LabelControl LblEnPahalıUrun;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.SidePanel sidePanel7;
        private System.Windows.Forms.PictureBox pictureBox2;
        private DevExpress.XtraEditors.LabelControl LblToplamSatis;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.SidePanel sidePanel8;
        private System.Windows.Forms.PictureBox pictureBox3;
        private DevExpress.XtraEditors.LabelControl LblToplamMarka;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.SidePanel sidePanel9;
        private System.Windows.Forms.PictureBox pictureBox13;
        private DevExpress.XtraEditors.LabelControl LblKritikSeviye;
        private DevExpress.XtraEditors.LabelControl labelControl18;
        private DevExpress.XtraEditors.SidePanel sidePanel10;
        private System.Windows.Forms.PictureBox pictureBox14;
        private DevExpress.XtraEditors.LabelControl LblToplamStok;
        private DevExpress.XtraEditors.LabelControl labelControl20;
        private DevExpress.XtraEditors.SidePanel sidePanel11;
        private System.Windows.Forms.PictureBox pictureBox15;
        private DevExpress.XtraEditors.LabelControl LblEnsonSaturun;
        private DevExpress.XtraEditors.LabelControl labelControl22;
        private DevExpress.XtraEditors.SidePanel sidePanel12;
        private System.Windows.Forms.PictureBox pictureBox16;
        private DevExpress.XtraEditors.LabelControl LblEnsonurun;
        private DevExpress.XtraEditors.LabelControl labelControl24;
        private DevExpress.XtraEditors.SidePanel sidePanel13;
        private System.Windows.Forms.PictureBox pictureBox9;
        private DevExpress.XtraEditors.LabelControl LblKasa;
        private DevExpress.XtraEditors.LabelControl labelControl26;
        private DevExpress.XtraEditors.SidePanel sidePanel14;
        private System.Windows.Forms.PictureBox pictureBox10;
        private DevExpress.XtraEditors.LabelControl LblToplamAlimTutar;
        private DevExpress.XtraEditors.LabelControl labelControl28;
        private DevExpress.XtraEditors.SidePanel sidePanel15;
        private System.Windows.Forms.PictureBox pictureBox11;
        private DevExpress.XtraEditors.LabelControl LblToplamAlim;
        private DevExpress.XtraEditors.LabelControl labelControl30;
        private DevExpress.XtraEditors.SidePanel sidePanel16;
        private System.Windows.Forms.PictureBox pictureBox12;
        private DevExpress.XtraEditors.LabelControl LblKaçFarkliil;
        private DevExpress.XtraEditors.LabelControl labelControl32;
    }
}