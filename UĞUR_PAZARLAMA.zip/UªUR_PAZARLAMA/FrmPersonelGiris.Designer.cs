﻿
namespace UĞUR_PAZARLAMA
{
    partial class FrmPersonelGiris
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPersonelGiris));
            this.LblKasa = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.pictureEdit2 = new DevExpress.XtraEditors.PictureEdit();
            this.pictureEdit3 = new DevExpress.XtraEditors.PictureEdit();
            this.BtnUrunListesi = new DevExpress.XtraEditors.SimpleButton();
            this.BtnKategoriListesi = new DevExpress.XtraEditors.SimpleButton();
            this.BtnSatisListesi = new DevExpress.XtraEditors.SimpleButton();
            this.BtnMarkaListesi = new DevExpress.XtraEditors.SimpleButton();
            this.BtnMüsteriListesi = new DevExpress.XtraEditors.SimpleButton();
            this.BtnIstatistikler = new DevExpress.XtraEditors.SimpleButton();
            this.BtnMarkaEkle = new DevExpress.XtraEditors.SimpleButton();
            this.BtnSatisYap = new DevExpress.XtraEditors.SimpleButton();
            this.BtnUrunEkle = new DevExpress.XtraEditors.SimpleButton();
            this.BtnMüsteriEkle = new DevExpress.XtraEditors.SimpleButton();
            this.BtnKategoriEkle = new DevExpress.XtraEditors.SimpleButton();
            this.checkEdit1 = new DevExpress.XtraEditors.CheckEdit();
            this.BtnBilgilerimiGüncelle = new DevExpress.XtraEditors.SimpleButton();
            this.pictureEdit1 = new DevExpress.XtraEditors.PictureEdit();
            this.LblStatu = new DevExpress.XtraEditors.LabelControl();
            this.LblAdSoyad = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.sidePanel2 = new DevExpress.XtraEditors.SidePanel();
            this.LblTarih = new DevExpress.XtraEditors.LabelControl();
            this.LblSaat = new DevExpress.XtraEditors.LabelControl();
            this.sidePanel3 = new DevExpress.XtraEditors.SidePanel();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit1.Properties)).BeginInit();
            this.sidePanel2.SuspendLayout();
            this.sidePanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // LblKasa
            // 
            this.LblKasa.Appearance.BackColor = System.Drawing.Color.DimGray;
            this.LblKasa.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblKasa.Appearance.ForeColor = System.Drawing.Color.White;
            this.LblKasa.Appearance.Options.UseBackColor = true;
            this.LblKasa.Appearance.Options.UseFont = true;
            this.LblKasa.Appearance.Options.UseForeColor = true;
            this.LblKasa.Location = new System.Drawing.Point(60, 431);
            this.LblKasa.Name = "LblKasa";
            this.LblKasa.Size = new System.Drawing.Size(32, 19);
            this.LblKasa.TabIndex = 70;
            this.LblKasa.Text = "0 TL";
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.BackColor = System.Drawing.Color.DimGray;
            this.labelControl8.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl8.Appearance.ForeColor = System.Drawing.Color.White;
            this.labelControl8.Appearance.Options.UseBackColor = true;
            this.labelControl8.Appearance.Options.UseFont = true;
            this.labelControl8.Appearance.Options.UseForeColor = true;
            this.labelControl8.Location = new System.Drawing.Point(76, 386);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(40, 19);
            this.labelControl8.TabIndex = 69;
            this.labelControl8.Text = "KASA";
            // 
            // pictureEdit2
            // 
            this.pictureEdit2.EditValue = ((object)(resources.GetObject("pictureEdit2.EditValue")));
            this.pictureEdit2.Location = new System.Drawing.Point(12, 344);
            this.pictureEdit2.Name = "pictureEdit2";
            this.pictureEdit2.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.pictureEdit2.Properties.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Stretch;
            this.pictureEdit2.Size = new System.Drawing.Size(202, 150);
            this.pictureEdit2.TabIndex = 68;
            // 
            // pictureEdit3
            // 
            this.pictureEdit3.EditValue = ((object)(resources.GetObject("pictureEdit3.EditValue")));
            this.pictureEdit3.Location = new System.Drawing.Point(1166, 1);
            this.pictureEdit3.Name = "pictureEdit3";
            this.pictureEdit3.Properties.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.pictureEdit3.Properties.Appearance.Options.UseBackColor = true;
            this.pictureEdit3.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.pictureEdit3.Size = new System.Drawing.Size(96, 70);
            this.pictureEdit3.TabIndex = 72;
            this.pictureEdit3.Click += new System.EventHandler(this.pictureEdit3_Click);
            // 
            // BtnUrunListesi
            // 
            this.BtnUrunListesi.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(195)))), ((int)(((byte)(229)))));
            this.BtnUrunListesi.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnUrunListesi.Appearance.Options.UseBackColor = true;
            this.BtnUrunListesi.Appearance.Options.UseFont = true;
            this.BtnUrunListesi.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("BtnUrunListesi.ImageOptions.Image")));
            this.BtnUrunListesi.Location = new System.Drawing.Point(240, 84);
            this.BtnUrunListesi.Name = "BtnUrunListesi";
            this.BtnUrunListesi.Size = new System.Drawing.Size(222, 50);
            this.BtnUrunListesi.TabIndex = 73;
            this.BtnUrunListesi.Text = "Ürün Listesi";
            this.BtnUrunListesi.Click += new System.EventHandler(this.BtnUrunListesi_Click);
            // 
            // BtnKategoriListesi
            // 
            this.BtnKategoriListesi.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(177)))), ((int)(((byte)(131)))));
            this.BtnKategoriListesi.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnKategoriListesi.Appearance.Options.UseBackColor = true;
            this.BtnKategoriListesi.Appearance.Options.UseFont = true;
            this.BtnKategoriListesi.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("BtnKategoriListesi.ImageOptions.Image")));
            this.BtnKategoriListesi.Location = new System.Drawing.Point(500, 84);
            this.BtnKategoriListesi.Name = "BtnKategoriListesi";
            this.BtnKategoriListesi.Size = new System.Drawing.Size(222, 50);
            this.BtnKategoriListesi.TabIndex = 74;
            this.BtnKategoriListesi.Text = "Kategori Listesi";
            this.BtnKategoriListesi.Click += new System.EventHandler(this.BtnKategoriListesi_Click);
            // 
            // BtnSatisListesi
            // 
            this.BtnSatisListesi.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(195)))), ((int)(((byte)(229)))));
            this.BtnSatisListesi.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnSatisListesi.Appearance.Options.UseBackColor = true;
            this.BtnSatisListesi.Appearance.Options.UseFont = true;
            this.BtnSatisListesi.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("BtnSatisListesi.ImageOptions.Image")));
            this.BtnSatisListesi.Location = new System.Drawing.Point(758, 84);
            this.BtnSatisListesi.Name = "BtnSatisListesi";
            this.BtnSatisListesi.Size = new System.Drawing.Size(222, 50);
            this.BtnSatisListesi.TabIndex = 75;
            this.BtnSatisListesi.Text = "Satış Listesi";
            this.BtnSatisListesi.Click += new System.EventHandler(this.BtnSatisListesi_Click);
            // 
            // BtnMarkaListesi
            // 
            this.BtnMarkaListesi.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(177)))), ((int)(((byte)(131)))));
            this.BtnMarkaListesi.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnMarkaListesi.Appearance.Options.UseBackColor = true;
            this.BtnMarkaListesi.Appearance.Options.UseFont = true;
            this.BtnMarkaListesi.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("BtnMarkaListesi.ImageOptions.Image")));
            this.BtnMarkaListesi.Location = new System.Drawing.Point(758, 162);
            this.BtnMarkaListesi.Name = "BtnMarkaListesi";
            this.BtnMarkaListesi.Size = new System.Drawing.Size(222, 50);
            this.BtnMarkaListesi.TabIndex = 78;
            this.BtnMarkaListesi.Text = "Marka Listesi";
            this.BtnMarkaListesi.Click += new System.EventHandler(this.BtnMarkaListesi_Click);
            // 
            // BtnMüsteriListesi
            // 
            this.BtnMüsteriListesi.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(195)))), ((int)(((byte)(229)))));
            this.BtnMüsteriListesi.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnMüsteriListesi.Appearance.Options.UseBackColor = true;
            this.BtnMüsteriListesi.Appearance.Options.UseFont = true;
            this.BtnMüsteriListesi.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("BtnMüsteriListesi.ImageOptions.Image")));
            this.BtnMüsteriListesi.Location = new System.Drawing.Point(500, 162);
            this.BtnMüsteriListesi.Name = "BtnMüsteriListesi";
            this.BtnMüsteriListesi.Size = new System.Drawing.Size(222, 50);
            this.BtnMüsteriListesi.TabIndex = 77;
            this.BtnMüsteriListesi.Text = "Müşteri Listesi";
            this.BtnMüsteriListesi.Click += new System.EventHandler(this.BtnMüsteriListesi_Click);
            // 
            // BtnIstatistikler
            // 
            this.BtnIstatistikler.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(177)))), ((int)(((byte)(131)))));
            this.BtnIstatistikler.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnIstatistikler.Appearance.Options.UseBackColor = true;
            this.BtnIstatistikler.Appearance.Options.UseFont = true;
            this.BtnIstatistikler.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("BtnIstatistikler.ImageOptions.Image")));
            this.BtnIstatistikler.Location = new System.Drawing.Point(240, 162);
            this.BtnIstatistikler.Name = "BtnIstatistikler";
            this.BtnIstatistikler.Size = new System.Drawing.Size(222, 50);
            this.BtnIstatistikler.TabIndex = 76;
            this.BtnIstatistikler.Text = "İstatistikler";
            this.BtnIstatistikler.Click += new System.EventHandler(this.BtnIstatistikler_Click);
            // 
            // BtnMarkaEkle
            // 
            this.BtnMarkaEkle.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(177)))), ((int)(((byte)(131)))));
            this.BtnMarkaEkle.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnMarkaEkle.Appearance.Options.UseBackColor = true;
            this.BtnMarkaEkle.Appearance.Options.UseFont = true;
            this.BtnMarkaEkle.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("BtnMarkaEkle.ImageOptions.Image")));
            this.BtnMarkaEkle.Location = new System.Drawing.Point(1030, 273);
            this.BtnMarkaEkle.Name = "BtnMarkaEkle";
            this.BtnMarkaEkle.Size = new System.Drawing.Size(222, 50);
            this.BtnMarkaEkle.TabIndex = 80;
            this.BtnMarkaEkle.Text = "Marka Ekle";
            this.BtnMarkaEkle.Click += new System.EventHandler(this.BtnMarkaEkle_Click);
            // 
            // BtnSatisYap
            // 
            this.BtnSatisYap.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(195)))), ((int)(((byte)(229)))));
            this.BtnSatisYap.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnSatisYap.Appearance.Options.UseBackColor = true;
            this.BtnSatisYap.Appearance.Options.UseFont = true;
            this.BtnSatisYap.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("BtnSatisYap.ImageOptions.Image")));
            this.BtnSatisYap.Location = new System.Drawing.Point(1030, 217);
            this.BtnSatisYap.Name = "BtnSatisYap";
            this.BtnSatisYap.Size = new System.Drawing.Size(222, 50);
            this.BtnSatisYap.TabIndex = 79;
            this.BtnSatisYap.Text = "Satış Yap";
            this.BtnSatisYap.Click += new System.EventHandler(this.BtnSatisYap_Click);
            // 
            // BtnUrunEkle
            // 
            this.BtnUrunEkle.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(177)))), ((int)(((byte)(131)))));
            this.BtnUrunEkle.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnUrunEkle.Appearance.Options.UseBackColor = true;
            this.BtnUrunEkle.Appearance.Options.UseFont = true;
            this.BtnUrunEkle.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("BtnUrunEkle.ImageOptions.Image")));
            this.BtnUrunEkle.Location = new System.Drawing.Point(1030, 386);
            this.BtnUrunEkle.Name = "BtnUrunEkle";
            this.BtnUrunEkle.Size = new System.Drawing.Size(222, 50);
            this.BtnUrunEkle.TabIndex = 82;
            this.BtnUrunEkle.Text = "Ürün Ekle";
            this.BtnUrunEkle.Click += new System.EventHandler(this.BtnUrunEkle_Click);
            // 
            // BtnMüsteriEkle
            // 
            this.BtnMüsteriEkle.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(195)))), ((int)(((byte)(229)))));
            this.BtnMüsteriEkle.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnMüsteriEkle.Appearance.Options.UseBackColor = true;
            this.BtnMüsteriEkle.Appearance.Options.UseFont = true;
            this.BtnMüsteriEkle.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("BtnMüsteriEkle.ImageOptions.Image")));
            this.BtnMüsteriEkle.Location = new System.Drawing.Point(1030, 330);
            this.BtnMüsteriEkle.Name = "BtnMüsteriEkle";
            this.BtnMüsteriEkle.Size = new System.Drawing.Size(222, 50);
            this.BtnMüsteriEkle.TabIndex = 81;
            this.BtnMüsteriEkle.Text = "Müşteri Ekle";
            this.BtnMüsteriEkle.Click += new System.EventHandler(this.BtnMüsteriEkle_Click);
            // 
            // BtnKategoriEkle
            // 
            this.BtnKategoriEkle.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(195)))), ((int)(((byte)(229)))));
            this.BtnKategoriEkle.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnKategoriEkle.Appearance.Options.UseBackColor = true;
            this.BtnKategoriEkle.Appearance.Options.UseFont = true;
            this.BtnKategoriEkle.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("BtnKategoriEkle.ImageOptions.Image")));
            this.BtnKategoriEkle.Location = new System.Drawing.Point(1030, 444);
            this.BtnKategoriEkle.Name = "BtnKategoriEkle";
            this.BtnKategoriEkle.Size = new System.Drawing.Size(222, 50);
            this.BtnKategoriEkle.TabIndex = 83;
            this.BtnKategoriEkle.Text = "Kategori Ekle";
            this.BtnKategoriEkle.Click += new System.EventHandler(this.BtnKategoriEkle_Click);
            // 
            // checkEdit1
            // 
            this.checkEdit1.Location = new System.Drawing.Point(222, 227);
            this.checkEdit1.Name = "checkEdit1";
            this.checkEdit1.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.checkEdit1.Properties.Appearance.ForeColor = System.Drawing.Color.White;
            this.checkEdit1.Properties.Appearance.Options.UseFont = true;
            this.checkEdit1.Properties.Appearance.Options.UseForeColor = true;
            this.checkEdit1.Properties.Caption = "Bana Ait Satışlar";
            this.checkEdit1.Size = new System.Drawing.Size(151, 23);
            this.checkEdit1.TabIndex = 86;
            this.checkEdit1.CheckedChanged += new System.EventHandler(this.checkEdit1_CheckedChanged);
            // 
            // BtnBilgilerimiGüncelle
            // 
            this.BtnBilgilerimiGüncelle.Appearance.BackColor = System.Drawing.Color.DodgerBlue;
            this.BtnBilgilerimiGüncelle.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnBilgilerimiGüncelle.Appearance.ForeColor = System.Drawing.Color.Yellow;
            this.BtnBilgilerimiGüncelle.Appearance.Options.UseBackColor = true;
            this.BtnBilgilerimiGüncelle.Appearance.Options.UseFont = true;
            this.BtnBilgilerimiGüncelle.Appearance.Options.UseForeColor = true;
            this.BtnBilgilerimiGüncelle.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("BtnBilgilerimiGüncelle.ImageOptions.Image")));
            this.BtnBilgilerimiGüncelle.Location = new System.Drawing.Point(12, 273);
            this.BtnBilgilerimiGüncelle.Name = "BtnBilgilerimiGüncelle";
            this.BtnBilgilerimiGüncelle.Size = new System.Drawing.Size(184, 38);
            this.BtnBilgilerimiGüncelle.TabIndex = 90;
            this.BtnBilgilerimiGüncelle.Text = "Bilgilerimi Güncelle";
            this.BtnBilgilerimiGüncelle.Click += new System.EventHandler(this.BtnBilgilerimiGüncelle_Click);
            // 
            // pictureEdit1
            // 
            this.pictureEdit1.Location = new System.Drawing.Point(12, 12);
            this.pictureEdit1.Name = "pictureEdit1";
            this.pictureEdit1.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.pictureEdit1.Properties.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Stretch;
            this.pictureEdit1.Size = new System.Drawing.Size(184, 169);
            this.pictureEdit1.TabIndex = 87;
            // 
            // LblStatu
            // 
            this.LblStatu.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblStatu.Appearance.ForeColor = System.Drawing.Color.White;
            this.LblStatu.Appearance.Options.UseFont = true;
            this.LblStatu.Appearance.Options.UseForeColor = true;
            this.LblStatu.Location = new System.Drawing.Point(22, 231);
            this.LblStatu.Name = "LblStatu";
            this.LblStatu.Size = new System.Drawing.Size(94, 19);
            this.LblStatu.TabIndex = 88;
            this.LblStatu.Text = "labelControl1";
            // 
            // LblAdSoyad
            // 
            this.LblAdSoyad.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblAdSoyad.Appearance.ForeColor = System.Drawing.Color.White;
            this.LblAdSoyad.Appearance.Options.UseFont = true;
            this.LblAdSoyad.Appearance.Options.UseForeColor = true;
            this.LblAdSoyad.Location = new System.Drawing.Point(22, 192);
            this.LblAdSoyad.Name = "LblAdSoyad";
            this.LblAdSoyad.Size = new System.Drawing.Size(94, 19);
            this.LblAdSoyad.TabIndex = 89;
            this.LblAdSoyad.Text = "labelControl1";
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.White;
            this.labelControl1.Appearance.Options.UseFont = true;
            this.labelControl1.Appearance.Options.UseForeColor = true;
            this.labelControl1.Location = new System.Drawing.Point(81, 17);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(292, 42);
            this.labelControl1.TabIndex = 0;
            this.labelControl1.Text = "UĞUR PAZARLAMA";
            // 
            // sidePanel2
            // 
            this.sidePanel2.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(87)))), ((int)(((byte)(164)))));
            this.sidePanel2.Appearance.Options.UseBackColor = true;
            this.sidePanel2.Controls.Add(this.labelControl1);
            this.sidePanel2.Location = new System.Drawing.Point(471, 1);
            this.sidePanel2.Name = "sidePanel2";
            this.sidePanel2.Size = new System.Drawing.Size(456, 70);
            this.sidePanel2.TabIndex = 71;
            this.sidePanel2.Text = "sidePanel2";
            // 
            // LblTarih
            // 
            this.LblTarih.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblTarih.Appearance.ForeColor = System.Drawing.Color.Yellow;
            this.LblTarih.Appearance.Options.UseFont = true;
            this.LblTarih.Appearance.Options.UseForeColor = true;
            this.LblTarih.Location = new System.Drawing.Point(26, 31);
            this.LblTarih.Name = "LblTarih";
            this.LblTarih.Size = new System.Drawing.Size(28, 19);
            this.LblTarih.TabIndex = 3;
            this.LblTarih.Text = "Null";
            // 
            // LblSaat
            // 
            this.LblSaat.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblSaat.Appearance.ForeColor = System.Drawing.Color.Yellow;
            this.LblSaat.Appearance.Options.UseFont = true;
            this.LblSaat.Appearance.Options.UseForeColor = true;
            this.LblSaat.Location = new System.Drawing.Point(96, 78);
            this.LblSaat.Name = "LblSaat";
            this.LblSaat.Size = new System.Drawing.Size(28, 19);
            this.LblSaat.TabIndex = 2;
            this.LblSaat.Text = "Null";
            // 
            // sidePanel3
            // 
            this.sidePanel3.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(87)))), ((int)(((byte)(164)))));
            this.sidePanel3.Appearance.Options.UseBackColor = true;
            this.sidePanel3.Controls.Add(this.LblSaat);
            this.sidePanel3.Controls.Add(this.LblTarih);
            this.sidePanel3.Location = new System.Drawing.Point(986, 84);
            this.sidePanel3.Name = "sidePanel3";
            this.sidePanel3.Size = new System.Drawing.Size(266, 127);
            this.sidePanel3.TabIndex = 84;
            this.sidePanel3.Text = "sidePanel3";
            // 
            // gridControl1
            // 
            this.gridControl1.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(1);
            this.gridControl1.Location = new System.Drawing.Point(220, 256);
            this.gridControl1.MainView = this.gridView1;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.Size = new System.Drawing.Size(802, 248);
            this.gridControl1.TabIndex = 91;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.GridControl = this.gridControl1;
            this.gridView1.Name = "gridView1";
            // 
            // FrmPersonelGiris
            // 
            this.Appearance.BackColor = System.Drawing.Color.Gray;
            this.Appearance.Options.UseBackColor = true;
            this.Appearance.Options.UseFont = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 506);
            this.Controls.Add(this.gridControl1);
            this.Controls.Add(this.BtnBilgilerimiGüncelle);
            this.Controls.Add(this.pictureEdit1);
            this.Controls.Add(this.LblStatu);
            this.Controls.Add(this.LblAdSoyad);
            this.Controls.Add(this.checkEdit1);
            this.Controls.Add(this.sidePanel3);
            this.Controls.Add(this.BtnKategoriEkle);
            this.Controls.Add(this.BtnUrunEkle);
            this.Controls.Add(this.BtnMüsteriEkle);
            this.Controls.Add(this.BtnMarkaEkle);
            this.Controls.Add(this.BtnSatisYap);
            this.Controls.Add(this.BtnMarkaListesi);
            this.Controls.Add(this.BtnMüsteriListesi);
            this.Controls.Add(this.BtnIstatistikler);
            this.Controls.Add(this.BtnSatisListesi);
            this.Controls.Add(this.BtnKategoriListesi);
            this.Controls.Add(this.BtnUrunListesi);
            this.Controls.Add(this.pictureEdit3);
            this.Controls.Add(this.sidePanel2);
            this.Controls.Add(this.LblKasa);
            this.Controls.Add(this.labelControl8);
            this.Controls.Add(this.pictureEdit2);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmPersonelGiris";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmPersonelGiris";
            this.Load += new System.EventHandler(this.FrmPersonelGiris_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit1.Properties)).EndInit();
            this.sidePanel2.ResumeLayout(false);
            this.sidePanel2.PerformLayout();
            this.sidePanel3.ResumeLayout(false);
            this.sidePanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private DevExpress.XtraEditors.LabelControl LblKasa;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.PictureEdit pictureEdit2;
        private DevExpress.XtraEditors.PictureEdit pictureEdit3;
        private DevExpress.XtraEditors.SimpleButton BtnUrunListesi;
        private DevExpress.XtraEditors.SimpleButton BtnKategoriListesi;
        private DevExpress.XtraEditors.SimpleButton BtnSatisListesi;
        private DevExpress.XtraEditors.SimpleButton BtnMarkaListesi;
        private DevExpress.XtraEditors.SimpleButton BtnMüsteriListesi;
        private DevExpress.XtraEditors.SimpleButton BtnIstatistikler;
        private DevExpress.XtraEditors.SimpleButton BtnMarkaEkle;
        private DevExpress.XtraEditors.SimpleButton BtnSatisYap;
        private DevExpress.XtraEditors.SimpleButton BtnUrunEkle;
        private DevExpress.XtraEditors.SimpleButton BtnMüsteriEkle;
        private DevExpress.XtraEditors.SimpleButton BtnKategoriEkle;
        private DevExpress.XtraEditors.CheckEdit checkEdit1;
        private DevExpress.XtraEditors.SimpleButton BtnBilgilerimiGüncelle;
        private DevExpress.XtraEditors.PictureEdit pictureEdit1;
        private DevExpress.XtraEditors.LabelControl LblStatu;
        private DevExpress.XtraEditors.LabelControl LblAdSoyad;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.SidePanel sidePanel2;
        private DevExpress.XtraEditors.LabelControl LblTarih;
        private DevExpress.XtraEditors.LabelControl LblSaat;
        private DevExpress.XtraEditors.SidePanel sidePanel3;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
    }
}