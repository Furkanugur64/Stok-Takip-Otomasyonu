﻿
namespace UĞUR_PAZARLAMA
{
    partial class FrmSatis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmSatis));
            this.sidePanel2 = new DevExpress.XtraEditors.SidePanel();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.pictureEdit3 = new DevExpress.XtraEditors.PictureEdit();
            this.LblTarih = new DevExpress.XtraEditors.LabelControl();
            this.LblSaat = new DevExpress.XtraEditors.LabelControl();
            this.pictureEdit1 = new DevExpress.XtraEditors.PictureEdit();
            this.TxtBarkodNo = new DevExpress.XtraEditors.TextEdit();
            this.TxtOzellik = new DevExpress.XtraEditors.MemoEdit();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.TxtFiyat = new DevExpress.XtraEditors.TextEdit();
            this.TxtUrunAdi = new DevExpress.XtraEditors.TextEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.TxtStok = new DevExpress.XtraEditors.TextEdit();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.TxtPerTelefon = new DevExpress.XtraEditors.TextEdit();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.TxtYetki = new DevExpress.XtraEditors.TextEdit();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.TxtTc = new DevExpress.XtraEditors.TextEdit();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.Cmbpersonel = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.TxtIlce = new DevExpress.XtraEditors.TextEdit();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.TxtTelefon = new DevExpress.XtraEditors.TextEdit();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.TxtIl = new DevExpress.XtraEditors.TextEdit();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.CmbMüsteri = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.LblToplamTutar = new DevExpress.XtraEditors.LabelControl();
            this.simpleButton2 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl20 = new DevExpress.XtraEditors.LabelControl();
            this.TxtAdet = new DevExpress.XtraEditors.TextEdit();
            this.LblAdet = new DevExpress.XtraEditors.LabelControl();
            this.TxtTarih = new DevExpress.XtraEditors.TextEdit();
            this.LblSAtTarih = new DevExpress.XtraEditors.LabelControl();
            this.TxtPersonel = new DevExpress.XtraEditors.TextEdit();
            this.LblPersonel = new DevExpress.XtraEditors.LabelControl();
            this.TxtMüsteri = new DevExpress.XtraEditors.TextEdit();
            this.LblMusteri = new DevExpress.XtraEditors.LabelControl();
            this.TxtUrun = new DevExpress.XtraEditors.TextEdit();
            this.LblUrun = new DevExpress.XtraEditors.LabelControl();
            this.simpleButton4 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton3 = new DevExpress.XtraEditors.SimpleButton();
            this.CmbMarka = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControl25 = new DevExpress.XtraEditors.LabelControl();
            this.CmbKategori = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControl24 = new DevExpress.XtraEditors.LabelControl();
            this.simpleButton5 = new DevExpress.XtraEditors.SimpleButton();
            this.TxtÜrünAdıAra = new DevExpress.XtraEditors.TextEdit();
            this.labelControl26 = new DevExpress.XtraEditors.LabelControl();
            this.simpleButton6 = new DevExpress.XtraEditors.SimpleButton();
            this.sidePanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtBarkodNo.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtOzellik.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtFiyat.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtUrunAdi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtStok.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtPerTelefon.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtYetki.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtTc.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cmbpersonel.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtIlce.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtTelefon.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtIl.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CmbMüsteri.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtAdet.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtTarih.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtPersonel.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtMüsteri.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtUrun.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CmbMarka.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CmbKategori.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtÜrünAdıAra.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // sidePanel2
            // 
            this.sidePanel2.Appearance.BackColor = System.Drawing.Color.DarkOrange;
            this.sidePanel2.Appearance.Options.UseBackColor = true;
            this.sidePanel2.Controls.Add(this.labelControl3);
            this.sidePanel2.Location = new System.Drawing.Point(332, 12);
            this.sidePanel2.Name = "sidePanel2";
            this.sidePanel2.Size = new System.Drawing.Size(374, 73);
            this.sidePanel2.TabIndex = 21;
            this.sidePanel2.Text = "sidePanel2";
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.Font = new System.Drawing.Font("Tahoma", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl3.Appearance.ForeColor = System.Drawing.Color.White;
            this.labelControl3.Appearance.Options.UseFont = true;
            this.labelControl3.Appearance.Options.UseForeColor = true;
            this.labelControl3.Location = new System.Drawing.Point(38, 14);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(292, 42);
            this.labelControl3.TabIndex = 0;
            this.labelControl3.Text = "UĞUR PAZARLAMA";
            // 
            // gridControl1
            // 
            this.gridControl1.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(1);
            this.gridControl1.Location = new System.Drawing.Point(7, 344);
            this.gridControl1.MainView = this.gridView1;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.Size = new System.Drawing.Size(802, 216);
            this.gridControl1.TabIndex = 24;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.GridControl = this.gridControl1;
            this.gridView1.Name = "gridView1";
            // 
            // pictureEdit3
            // 
            this.pictureEdit3.EditValue = ((object)(resources.GetObject("pictureEdit3.EditValue")));
            this.pictureEdit3.Location = new System.Drawing.Point(1018, 1);
            this.pictureEdit3.Name = "pictureEdit3";
            this.pictureEdit3.Properties.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.pictureEdit3.Properties.Appearance.Options.UseBackColor = true;
            this.pictureEdit3.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.pictureEdit3.Size = new System.Drawing.Size(65, 57);
            this.pictureEdit3.TabIndex = 69;
            this.pictureEdit3.Click += new System.EventHandler(this.pictureEdit3_Click);
            // 
            // LblTarih
            // 
            this.LblTarih.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblTarih.Appearance.ForeColor = System.Drawing.Color.Red;
            this.LblTarih.Appearance.Options.UseFont = true;
            this.LblTarih.Appearance.Options.UseForeColor = true;
            this.LblTarih.Location = new System.Drawing.Point(598, 275);
            this.LblTarih.Name = "LblTarih";
            this.LblTarih.Size = new System.Drawing.Size(28, 19);
            this.LblTarih.TabIndex = 94;
            this.LblTarih.Text = "Null";
            // 
            // LblSaat
            // 
            this.LblSaat.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblSaat.Appearance.ForeColor = System.Drawing.Color.Red;
            this.LblSaat.Appearance.Options.UseFont = true;
            this.LblSaat.Appearance.Options.UseForeColor = true;
            this.LblSaat.Location = new System.Drawing.Point(611, 319);
            this.LblSaat.Name = "LblSaat";
            this.LblSaat.Size = new System.Drawing.Size(28, 19);
            this.LblSaat.TabIndex = 95;
            this.LblSaat.Text = "Null";
            // 
            // pictureEdit1
            // 
            this.pictureEdit1.Location = new System.Drawing.Point(391, 118);
            this.pictureEdit1.Name = "pictureEdit1";
            this.pictureEdit1.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.pictureEdit1.Size = new System.Drawing.Size(149, 122);
            this.pictureEdit1.TabIndex = 106;
            // 
            // TxtBarkodNo
            // 
            this.TxtBarkodNo.Enabled = false;
            this.TxtBarkodNo.Location = new System.Drawing.Point(101, 115);
            this.TxtBarkodNo.Name = "TxtBarkodNo";
            this.TxtBarkodNo.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.TxtBarkodNo.Properties.Appearance.Options.UseFont = true;
            this.TxtBarkodNo.Size = new System.Drawing.Size(122, 26);
            this.TxtBarkodNo.TabIndex = 103;
            // 
            // TxtOzellik
            // 
            this.TxtOzellik.Enabled = false;
            this.TxtOzellik.Location = new System.Drawing.Point(229, 149);
            this.TxtOzellik.Name = "TxtOzellik";
            this.TxtOzellik.Size = new System.Drawing.Size(156, 92);
            this.TxtOzellik.TabIndex = 104;
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl7.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.labelControl7.Appearance.Options.UseFont = true;
            this.labelControl7.Appearance.Options.UseForeColor = true;
            this.labelControl7.Location = new System.Drawing.Point(267, 118);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(94, 19);
            this.labelControl7.TabIndex = 105;
            this.labelControl7.Text = "ÖZELLİKLER:";
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl5.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.labelControl5.Appearance.Options.UseFont = true;
            this.labelControl5.Appearance.Options.UseForeColor = true;
            this.labelControl5.Location = new System.Drawing.Point(4, 122);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(91, 19);
            this.labelControl5.TabIndex = 102;
            this.labelControl5.Text = "BARKODNO:";
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.labelControl1.Appearance.Options.UseFont = true;
            this.labelControl1.Appearance.Options.UseForeColor = true;
            this.labelControl1.Location = new System.Drawing.Point(13, 147);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(82, 19);
            this.labelControl1.TabIndex = 96;
            this.labelControl1.Text = "ÜRÜN ADI:";
            // 
            // TxtFiyat
            // 
            this.TxtFiyat.Enabled = false;
            this.TxtFiyat.Location = new System.Drawing.Point(101, 216);
            this.TxtFiyat.Name = "TxtFiyat";
            this.TxtFiyat.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.TxtFiyat.Properties.Appearance.Options.UseFont = true;
            this.TxtFiyat.Properties.BeepOnError = false;
            this.TxtFiyat.Size = new System.Drawing.Size(122, 26);
            this.TxtFiyat.TabIndex = 101;
            // 
            // TxtUrunAdi
            // 
            this.TxtUrunAdi.Enabled = false;
            this.TxtUrunAdi.Location = new System.Drawing.Point(101, 147);
            this.TxtUrunAdi.Name = "TxtUrunAdi";
            this.TxtUrunAdi.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.TxtUrunAdi.Properties.Appearance.Options.UseFont = true;
            this.TxtUrunAdi.Size = new System.Drawing.Size(122, 26);
            this.TxtUrunAdi.TabIndex = 97;
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl4.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.labelControl4.Appearance.Options.UseFont = true;
            this.labelControl4.Appearance.Options.UseForeColor = true;
            this.labelControl4.Location = new System.Drawing.Point(44, 219);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(51, 19);
            this.labelControl4.TabIndex = 100;
            this.labelControl4.Text = "FİYAT:";
            // 
            // TxtStok
            // 
            this.TxtStok.Enabled = false;
            this.TxtStok.Location = new System.Drawing.Point(101, 179);
            this.TxtStok.Name = "TxtStok";
            this.TxtStok.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.TxtStok.Properties.Appearance.Options.UseFont = true;
            this.TxtStok.Size = new System.Drawing.Size(122, 26);
            this.TxtStok.TabIndex = 99;
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl2.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.labelControl2.Appearance.Options.UseFont = true;
            this.labelControl2.Appearance.Options.UseForeColor = true;
            this.labelControl2.Location = new System.Drawing.Point(49, 182);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(46, 19);
            this.labelControl2.TabIndex = 98;
            this.labelControl2.Text = "STOK:";
            // 
            // TxtPerTelefon
            // 
            this.TxtPerTelefon.Enabled = false;
            this.TxtPerTelefon.Location = new System.Drawing.Point(630, 183);
            this.TxtPerTelefon.Name = "TxtPerTelefon";
            this.TxtPerTelefon.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.TxtPerTelefon.Properties.Appearance.Options.UseFont = true;
            this.TxtPerTelefon.Properties.BeepOnError = false;
            this.TxtPerTelefon.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.RegExpMaskManager));
            this.TxtPerTelefon.Properties.MaskSettings.Set("mask", "(\\d\\d\\d) \\d\\d\\d-\\d\\d\\d\\d");
            this.TxtPerTelefon.Size = new System.Drawing.Size(154, 26);
            this.TxtPerTelefon.TabIndex = 108;
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl10.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.labelControl10.Appearance.Options.UseFont = true;
            this.labelControl10.Appearance.Options.UseForeColor = true;
            this.labelControl10.Location = new System.Drawing.Point(553, 190);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(73, 19);
            this.labelControl10.TabIndex = 107;
            this.labelControl10.Text = "TELEFON:";
            // 
            // TxtYetki
            // 
            this.TxtYetki.Enabled = false;
            this.TxtYetki.Location = new System.Drawing.Point(630, 218);
            this.TxtYetki.Name = "TxtYetki";
            this.TxtYetki.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.TxtYetki.Properties.Appearance.Options.UseFont = true;
            this.TxtYetki.Size = new System.Drawing.Size(154, 26);
            this.TxtYetki.TabIndex = 111;
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl8.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.labelControl8.Appearance.Options.UseFont = true;
            this.labelControl8.Appearance.Options.UseForeColor = true;
            this.labelControl8.Location = new System.Drawing.Point(576, 221);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(50, 19);
            this.labelControl8.TabIndex = 109;
            this.labelControl8.Text = "YETKİ:";
            // 
            // TxtTc
            // 
            this.TxtTc.Enabled = false;
            this.TxtTc.Location = new System.Drawing.Point(630, 151);
            this.TxtTc.Name = "TxtTc";
            this.TxtTc.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.TxtTc.Properties.Appearance.Options.UseFont = true;
            this.TxtTc.Properties.MaxLength = 11;
            this.TxtTc.Size = new System.Drawing.Size(154, 26);
            this.TxtTc.TabIndex = 113;
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl6.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.labelControl6.Appearance.Options.UseFont = true;
            this.labelControl6.Appearance.Options.UseForeColor = true;
            this.labelControl6.Location = new System.Drawing.Point(600, 154);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(26, 19);
            this.labelControl6.TabIndex = 112;
            this.labelControl6.Text = "TC:";
            // 
            // Cmbpersonel
            // 
            this.Cmbpersonel.Location = new System.Drawing.Point(630, 119);
            this.Cmbpersonel.Name = "Cmbpersonel";
            this.Cmbpersonel.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Cmbpersonel.Properties.Appearance.Options.UseFont = true;
            this.Cmbpersonel.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.Cmbpersonel.Properties.NullText = "İsim Seçiniz";
            this.Cmbpersonel.Size = new System.Drawing.Size(154, 26);
            this.Cmbpersonel.TabIndex = 114;
            this.Cmbpersonel.EditValueChanged += new System.EventHandler(this.Cmbpersonel_EditValueChanged);
            // 
            // labelControl9
            // 
            this.labelControl9.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl9.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.labelControl9.Appearance.Options.UseFont = true;
            this.labelControl9.Appearance.Options.UseForeColor = true;
            this.labelControl9.Location = new System.Drawing.Point(587, 122);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(39, 19);
            this.labelControl9.TabIndex = 110;
            this.labelControl9.Text = "İSİM:";
            // 
            // TxtIlce
            // 
            this.TxtIlce.Enabled = false;
            this.TxtIlce.Location = new System.Drawing.Point(899, 210);
            this.TxtIlce.Name = "TxtIlce";
            this.TxtIlce.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.TxtIlce.Properties.Appearance.Options.UseFont = true;
            this.TxtIlce.Size = new System.Drawing.Size(171, 26);
            this.TxtIlce.TabIndex = 122;
            // 
            // labelControl13
            // 
            this.labelControl13.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl13.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.labelControl13.Appearance.Options.UseFont = true;
            this.labelControl13.Appearance.Options.UseForeColor = true;
            this.labelControl13.Location = new System.Drawing.Point(857, 217);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(39, 19);
            this.labelControl13.TabIndex = 121;
            this.labelControl13.Text = "İLÇE:";
            // 
            // TxtTelefon
            // 
            this.TxtTelefon.Enabled = false;
            this.TxtTelefon.Location = new System.Drawing.Point(899, 147);
            this.TxtTelefon.Name = "TxtTelefon";
            this.TxtTelefon.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.TxtTelefon.Properties.Appearance.Options.UseFont = true;
            this.TxtTelefon.Properties.BeepOnError = false;
            this.TxtTelefon.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.RegExpMaskManager));
            this.TxtTelefon.Properties.MaskSettings.Set("mask", "(507) 099 4161");
            this.TxtTelefon.Size = new System.Drawing.Size(171, 26);
            this.TxtTelefon.TabIndex = 116;
            // 
            // labelControl11
            // 
            this.labelControl11.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl11.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.labelControl11.Appearance.Options.UseFont = true;
            this.labelControl11.Appearance.Options.UseForeColor = true;
            this.labelControl11.Location = new System.Drawing.Point(823, 150);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(73, 19);
            this.labelControl11.TabIndex = 115;
            this.labelControl11.Text = "TELEFON:";
            // 
            // TxtIl
            // 
            this.TxtIl.Enabled = false;
            this.TxtIl.Location = new System.Drawing.Point(899, 179);
            this.TxtIl.Name = "TxtIl";
            this.TxtIl.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.TxtIl.Properties.Appearance.Options.UseFont = true;
            this.TxtIl.Size = new System.Drawing.Size(171, 26);
            this.TxtIl.TabIndex = 119;
            // 
            // labelControl12
            // 
            this.labelControl12.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl12.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.labelControl12.Appearance.Options.UseFont = true;
            this.labelControl12.Appearance.Options.UseForeColor = true;
            this.labelControl12.Location = new System.Drawing.Point(876, 186);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(20, 19);
            this.labelControl12.TabIndex = 117;
            this.labelControl12.Text = "İL:";
            // 
            // CmbMüsteri
            // 
            this.CmbMüsteri.Location = new System.Drawing.Point(899, 115);
            this.CmbMüsteri.Name = "CmbMüsteri";
            this.CmbMüsteri.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.CmbMüsteri.Properties.Appearance.Options.UseFont = true;
            this.CmbMüsteri.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.CmbMüsteri.Properties.NullText = "Müşteri Seçiniz";
            this.CmbMüsteri.Size = new System.Drawing.Size(171, 26);
            this.CmbMüsteri.TabIndex = 120;
            this.CmbMüsteri.EditValueChanged += new System.EventHandler(this.MskAdSoyad_EditValueChanged);
            // 
            // labelControl14
            // 
            this.labelControl14.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl14.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.labelControl14.Appearance.Options.UseFont = true;
            this.labelControl14.Appearance.Options.UseForeColor = true;
            this.labelControl14.Location = new System.Drawing.Point(809, 118);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(87, 19);
            this.labelControl14.TabIndex = 118;
            this.labelControl14.Text = "AD-SOYAD:";
            // 
            // LblToplamTutar
            // 
            this.LblToplamTutar.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblToplamTutar.Appearance.ForeColor = System.Drawing.Color.Red;
            this.LblToplamTutar.Appearance.Options.UseFont = true;
            this.LblToplamTutar.Appearance.Options.UseForeColor = true;
            this.LblToplamTutar.Location = new System.Drawing.Point(960, 461);
            this.LblToplamTutar.Name = "LblToplamTutar";
            this.LblToplamTutar.Size = new System.Drawing.Size(32, 19);
            this.LblToplamTutar.TabIndex = 136;
            this.LblToplamTutar.Text = "0 TL";
            // 
            // simpleButton2
            // 
            this.simpleButton2.Appearance.BackColor = System.Drawing.Color.Red;
            this.simpleButton2.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.simpleButton2.Appearance.Options.UseBackColor = true;
            this.simpleButton2.Appearance.Options.UseFont = true;
            this.simpleButton2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton2.ImageOptions.Image")));
            this.simpleButton2.Location = new System.Drawing.Point(942, 497);
            this.simpleButton2.Name = "simpleButton2";
            this.simpleButton2.Size = new System.Drawing.Size(121, 46);
            this.simpleButton2.TabIndex = 124;
            this.simpleButton2.Text = "İptal";
            this.simpleButton2.Click += new System.EventHandler(this.simpleButton2_Click);
            // 
            // simpleButton1
            // 
            this.simpleButton1.Appearance.BackColor = System.Drawing.Color.Green;
            this.simpleButton1.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.simpleButton1.Appearance.Options.UseBackColor = true;
            this.simpleButton1.Appearance.Options.UseFont = true;
            this.simpleButton1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton1.ImageOptions.Image")));
            this.simpleButton1.Location = new System.Drawing.Point(815, 497);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.Size = new System.Drawing.Size(121, 46);
            this.simpleButton1.TabIndex = 123;
            this.simpleButton1.Text = "Satış Yap";
            this.simpleButton1.Click += new System.EventHandler(this.simpleButton1_Click);
            // 
            // labelControl20
            // 
            this.labelControl20.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl20.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl20.Appearance.Options.UseFont = true;
            this.labelControl20.Appearance.Options.UseForeColor = true;
            this.labelControl20.Location = new System.Drawing.Point(829, 461);
            this.labelControl20.Name = "labelControl20";
            this.labelControl20.Size = new System.Drawing.Size(125, 19);
            this.labelControl20.TabIndex = 135;
            this.labelControl20.Text = "TOPLAM TUTAR:";
            // 
            // TxtAdet
            // 
            this.TxtAdet.Location = new System.Drawing.Point(902, 414);
            this.TxtAdet.Name = "TxtAdet";
            this.TxtAdet.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.TxtAdet.Properties.Appearance.Options.UseFont = true;
            this.TxtAdet.Properties.BeepOnError = false;
            this.TxtAdet.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.TxtAdet.Properties.MaskSettings.Set("mask", "d");
            this.TxtAdet.Size = new System.Drawing.Size(171, 26);
            this.TxtAdet.TabIndex = 134;
            // 
            // LblAdet
            // 
            this.LblAdet.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblAdet.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.LblAdet.Appearance.Options.UseFont = true;
            this.LblAdet.Appearance.Options.UseForeColor = true;
            this.LblAdet.Location = new System.Drawing.Point(854, 421);
            this.LblAdet.Name = "LblAdet";
            this.LblAdet.Size = new System.Drawing.Size(47, 19);
            this.LblAdet.TabIndex = 133;
            this.LblAdet.Text = "ADET:";
            // 
            // TxtTarih
            // 
            this.TxtTarih.Location = new System.Drawing.Point(902, 382);
            this.TxtTarih.Name = "TxtTarih";
            this.TxtTarih.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.TxtTarih.Properties.Appearance.Options.UseFont = true;
            this.TxtTarih.Properties.BeepOnError = false;
            this.TxtTarih.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.DateTimeOffsetMaskManager));
            this.TxtTarih.Properties.MaskSettings.Set("MaskManagerSignature", "allowNull=False");
            this.TxtTarih.Properties.MaskSettings.Set("mask", "d");
            this.TxtTarih.Size = new System.Drawing.Size(171, 26);
            this.TxtTarih.TabIndex = 132;
            // 
            // LblSAtTarih
            // 
            this.LblSAtTarih.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblSAtTarih.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.LblSAtTarih.Appearance.Options.UseFont = true;
            this.LblSAtTarih.Appearance.Options.UseForeColor = true;
            this.LblSAtTarih.Location = new System.Drawing.Point(847, 389);
            this.LblSAtTarih.Name = "LblSAtTarih";
            this.LblSAtTarih.Size = new System.Drawing.Size(54, 19);
            this.LblSAtTarih.TabIndex = 131;
            this.LblSAtTarih.Text = "TARİH:";
            // 
            // TxtPersonel
            // 
            this.TxtPersonel.Enabled = false;
            this.TxtPersonel.Location = new System.Drawing.Point(902, 351);
            this.TxtPersonel.Name = "TxtPersonel";
            this.TxtPersonel.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.TxtPersonel.Properties.Appearance.Options.UseFont = true;
            this.TxtPersonel.Size = new System.Drawing.Size(171, 26);
            this.TxtPersonel.TabIndex = 130;
            // 
            // LblPersonel
            // 
            this.LblPersonel.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblPersonel.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.LblPersonel.Appearance.Options.UseFont = true;
            this.LblPersonel.Appearance.Options.UseForeColor = true;
            this.LblPersonel.Location = new System.Drawing.Point(818, 358);
            this.LblPersonel.Name = "LblPersonel";
            this.LblPersonel.Size = new System.Drawing.Size(83, 19);
            this.LblPersonel.TabIndex = 129;
            this.LblPersonel.Text = "PERSONEL:";
            // 
            // TxtMüsteri
            // 
            this.TxtMüsteri.Enabled = false;
            this.TxtMüsteri.Location = new System.Drawing.Point(902, 319);
            this.TxtMüsteri.Name = "TxtMüsteri";
            this.TxtMüsteri.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.TxtMüsteri.Properties.Appearance.Options.UseFont = true;
            this.TxtMüsteri.Size = new System.Drawing.Size(171, 26);
            this.TxtMüsteri.TabIndex = 128;
            // 
            // LblMusteri
            // 
            this.LblMusteri.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblMusteri.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.LblMusteri.Appearance.Options.UseFont = true;
            this.LblMusteri.Appearance.Options.UseForeColor = true;
            this.LblMusteri.Location = new System.Drawing.Point(828, 326);
            this.LblMusteri.Name = "LblMusteri";
            this.LblMusteri.Size = new System.Drawing.Size(73, 19);
            this.LblMusteri.TabIndex = 127;
            this.LblMusteri.Text = "MÜŞTERİ:";
            // 
            // TxtUrun
            // 
            this.TxtUrun.Enabled = false;
            this.TxtUrun.Location = new System.Drawing.Point(902, 288);
            this.TxtUrun.Name = "TxtUrun";
            this.TxtUrun.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.TxtUrun.Properties.Appearance.Options.UseFont = true;
            this.TxtUrun.Size = new System.Drawing.Size(171, 26);
            this.TxtUrun.TabIndex = 126;
            // 
            // LblUrun
            // 
            this.LblUrun.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LblUrun.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.LblUrun.Appearance.Options.UseFont = true;
            this.LblUrun.Appearance.Options.UseForeColor = true;
            this.LblUrun.Location = new System.Drawing.Point(852, 295);
            this.LblUrun.Name = "LblUrun";
            this.LblUrun.Size = new System.Drawing.Size(49, 19);
            this.LblUrun.TabIndex = 125;
            this.LblUrun.Text = "ÜRÜN:";
            // 
            // simpleButton4
            // 
            this.simpleButton4.Appearance.BackColor = System.Drawing.Color.Red;
            this.simpleButton4.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.simpleButton4.Appearance.Options.UseBackColor = true;
            this.simpleButton4.Appearance.Options.UseFont = true;
            this.simpleButton4.Location = new System.Drawing.Point(247, 302);
            this.simpleButton4.Name = "simpleButton4";
            this.simpleButton4.Size = new System.Drawing.Size(101, 28);
            this.simpleButton4.TabIndex = 142;
            this.simpleButton4.Text = "Sıfırla";
            // 
            // simpleButton3
            // 
            this.simpleButton3.Appearance.BackColor = System.Drawing.Color.Green;
            this.simpleButton3.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.simpleButton3.Appearance.Options.UseBackColor = true;
            this.simpleButton3.Appearance.Options.UseFont = true;
            this.simpleButton3.Location = new System.Drawing.Point(247, 271);
            this.simpleButton3.Name = "simpleButton3";
            this.simpleButton3.Size = new System.Drawing.Size(101, 28);
            this.simpleButton3.TabIndex = 137;
            this.simpleButton3.Text = "Listele";
            this.simpleButton3.Click += new System.EventHandler(this.simpleButton3_Click);
            // 
            // CmbMarka
            // 
            this.CmbMarka.Location = new System.Drawing.Point(102, 304);
            this.CmbMarka.Name = "CmbMarka";
            this.CmbMarka.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.CmbMarka.Properties.Appearance.Options.UseFont = true;
            this.CmbMarka.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.CmbMarka.Properties.NullText = "";
            this.CmbMarka.Size = new System.Drawing.Size(141, 26);
            this.CmbMarka.TabIndex = 141;
            // 
            // labelControl25
            // 
            this.labelControl25.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl25.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl25.Appearance.Options.UseFont = true;
            this.labelControl25.Appearance.Options.UseForeColor = true;
            this.labelControl25.Location = new System.Drawing.Point(36, 307);
            this.labelControl25.Name = "labelControl25";
            this.labelControl25.Size = new System.Drawing.Size(59, 19);
            this.labelControl25.TabIndex = 140;
            this.labelControl25.Text = "MARKA:";
            // 
            // CmbKategori
            // 
            this.CmbKategori.Location = new System.Drawing.Point(102, 272);
            this.CmbKategori.Name = "CmbKategori";
            this.CmbKategori.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.CmbKategori.Properties.Appearance.Options.UseFont = true;
            this.CmbKategori.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.CmbKategori.Properties.NullText = "Kategori Seçiniz";
            this.CmbKategori.Size = new System.Drawing.Size(141, 26);
            this.CmbKategori.TabIndex = 139;
            // 
            // labelControl24
            // 
            this.labelControl24.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl24.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl24.Appearance.Options.UseFont = true;
            this.labelControl24.Appearance.Options.UseForeColor = true;
            this.labelControl24.Location = new System.Drawing.Point(11, 275);
            this.labelControl24.Name = "labelControl24";
            this.labelControl24.Size = new System.Drawing.Size(84, 19);
            this.labelControl24.TabIndex = 138;
            this.labelControl24.Text = "KATEGORİ:";
            // 
            // simpleButton5
            // 
            this.simpleButton5.Appearance.BackColor = System.Drawing.Color.Red;
            this.simpleButton5.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.simpleButton5.Appearance.Options.UseBackColor = true;
            this.simpleButton5.Appearance.Options.UseFont = true;
            this.simpleButton5.Location = new System.Drawing.Point(556, 309);
            this.simpleButton5.Name = "simpleButton5";
            this.simpleButton5.Size = new System.Drawing.Size(20, 20);
            this.simpleButton5.TabIndex = 147;
            // 
            // TxtÜrünAdıAra
            // 
            this.TxtÜrünAdıAra.Location = new System.Drawing.Point(435, 291);
            this.TxtÜrünAdıAra.Name = "TxtÜrünAdıAra";
            this.TxtÜrünAdıAra.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.TxtÜrünAdıAra.Properties.Appearance.Options.UseFont = true;
            this.TxtÜrünAdıAra.Properties.BeepOnError = false;
            this.TxtÜrünAdıAra.Size = new System.Drawing.Size(105, 22);
            this.TxtÜrünAdıAra.TabIndex = 146;
            this.TxtÜrünAdıAra.EditValueChanged += new System.EventHandler(this.TxtÜrünAdıAra_EditValueChanged);
            // 
            // labelControl26
            // 
            this.labelControl26.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl26.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl26.Appearance.Options.UseFont = true;
            this.labelControl26.Appearance.Options.UseForeColor = true;
            this.labelControl26.Location = new System.Drawing.Point(371, 294);
            this.labelControl26.Name = "labelControl26";
            this.labelControl26.Size = new System.Drawing.Size(61, 16);
            this.labelControl26.TabIndex = 145;
            this.labelControl26.Text = "ÜRÜN ADI:";
            this.labelControl26.Click += new System.EventHandler(this.labelControl26_Click);
            // 
            // simpleButton6
            // 
            this.simpleButton6.Appearance.BackColor = System.Drawing.Color.Aqua;
            this.simpleButton6.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.simpleButton6.Appearance.Options.UseBackColor = true;
            this.simpleButton6.Appearance.Options.UseFont = true;
            this.simpleButton6.Location = new System.Drawing.Point(1005, 446);
            this.simpleButton6.Name = "simpleButton6";
            this.simpleButton6.Size = new System.Drawing.Size(68, 39);
            this.simpleButton6.TabIndex = 148;
            this.simpleButton6.Text = "Hesapla";
            this.simpleButton6.Click += new System.EventHandler(this.simpleButton6_Click);
            // 
            // FrmSatis
            // 
            this.Appearance.BackColor = System.Drawing.Color.Yellow;
            this.Appearance.Options.UseBackColor = true;
            this.Appearance.Options.UseFont = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1085, 583);
            this.Controls.Add(this.simpleButton6);
            this.Controls.Add(this.simpleButton5);
            this.Controls.Add(this.TxtÜrünAdıAra);
            this.Controls.Add(this.labelControl26);
            this.Controls.Add(this.simpleButton4);
            this.Controls.Add(this.simpleButton3);
            this.Controls.Add(this.CmbMarka);
            this.Controls.Add(this.labelControl25);
            this.Controls.Add(this.CmbKategori);
            this.Controls.Add(this.labelControl24);
            this.Controls.Add(this.LblToplamTutar);
            this.Controls.Add(this.simpleButton2);
            this.Controls.Add(this.simpleButton1);
            this.Controls.Add(this.labelControl20);
            this.Controls.Add(this.TxtAdet);
            this.Controls.Add(this.LblAdet);
            this.Controls.Add(this.TxtTarih);
            this.Controls.Add(this.LblSAtTarih);
            this.Controls.Add(this.TxtPersonel);
            this.Controls.Add(this.LblPersonel);
            this.Controls.Add(this.TxtMüsteri);
            this.Controls.Add(this.LblMusteri);
            this.Controls.Add(this.TxtUrun);
            this.Controls.Add(this.LblUrun);
            this.Controls.Add(this.TxtIlce);
            this.Controls.Add(this.labelControl13);
            this.Controls.Add(this.TxtTelefon);
            this.Controls.Add(this.labelControl11);
            this.Controls.Add(this.TxtIl);
            this.Controls.Add(this.labelControl12);
            this.Controls.Add(this.CmbMüsteri);
            this.Controls.Add(this.labelControl14);
            this.Controls.Add(this.TxtPerTelefon);
            this.Controls.Add(this.labelControl10);
            this.Controls.Add(this.TxtYetki);
            this.Controls.Add(this.labelControl8);
            this.Controls.Add(this.TxtTc);
            this.Controls.Add(this.labelControl6);
            this.Controls.Add(this.Cmbpersonel);
            this.Controls.Add(this.labelControl9);
            this.Controls.Add(this.pictureEdit1);
            this.Controls.Add(this.TxtBarkodNo);
            this.Controls.Add(this.TxtOzellik);
            this.Controls.Add(this.labelControl7);
            this.Controls.Add(this.labelControl5);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.TxtFiyat);
            this.Controls.Add(this.TxtUrunAdi);
            this.Controls.Add(this.labelControl4);
            this.Controls.Add(this.TxtStok);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.LblSaat);
            this.Controls.Add(this.LblTarih);
            this.Controls.Add(this.pictureEdit3);
            this.Controls.Add(this.gridControl1);
            this.Controls.Add(this.sidePanel2);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmSatis";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmSatis";
            this.Load += new System.EventHandler(this.FrmSatis_Load);
            this.sidePanel2.ResumeLayout(false);
            this.sidePanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtBarkodNo.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtOzellik.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtFiyat.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtUrunAdi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtStok.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtPerTelefon.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtYetki.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtTc.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cmbpersonel.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtIlce.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtTelefon.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtIl.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CmbMüsteri.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtAdet.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtTarih.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtPersonel.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtMüsteri.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtUrun.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CmbMarka.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CmbKategori.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtÜrünAdıAra.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private DevExpress.XtraEditors.SidePanel sidePanel2;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraEditors.PictureEdit pictureEdit3;
        private DevExpress.XtraEditors.LabelControl LblTarih;
        private DevExpress.XtraEditors.LabelControl LblSaat;
        private DevExpress.XtraEditors.PictureEdit pictureEdit1;
        private DevExpress.XtraEditors.TextEdit TxtBarkodNo;
        private DevExpress.XtraEditors.MemoEdit TxtOzellik;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.TextEdit TxtFiyat;
        private DevExpress.XtraEditors.TextEdit TxtUrunAdi;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.TextEdit TxtStok;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.TextEdit TxtPerTelefon;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.TextEdit TxtYetki;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.TextEdit TxtTc;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LookUpEdit Cmbpersonel;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.TextEdit TxtIlce;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.TextEdit TxtTelefon;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.TextEdit TxtIl;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.LookUpEdit CmbMüsteri;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.LabelControl LblToplamTutar;
        private DevExpress.XtraEditors.SimpleButton simpleButton2;
        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        private DevExpress.XtraEditors.LabelControl labelControl20;
        private DevExpress.XtraEditors.TextEdit TxtAdet;
        private DevExpress.XtraEditors.LabelControl LblAdet;
        private DevExpress.XtraEditors.TextEdit TxtTarih;
        private DevExpress.XtraEditors.LabelControl LblSAtTarih;
        private DevExpress.XtraEditors.TextEdit TxtPersonel;
        private DevExpress.XtraEditors.LabelControl LblPersonel;
        private DevExpress.XtraEditors.TextEdit TxtMüsteri;
        private DevExpress.XtraEditors.LabelControl LblMusteri;
        private DevExpress.XtraEditors.TextEdit TxtUrun;
        private DevExpress.XtraEditors.LabelControl LblUrun;
        private DevExpress.XtraEditors.SimpleButton simpleButton4;
        private DevExpress.XtraEditors.SimpleButton simpleButton3;
        private DevExpress.XtraEditors.LookUpEdit CmbMarka;
        private DevExpress.XtraEditors.LabelControl labelControl25;
        private DevExpress.XtraEditors.LookUpEdit CmbKategori;
        private DevExpress.XtraEditors.LabelControl labelControl24;
        private DevExpress.XtraEditors.SimpleButton simpleButton5;
        private DevExpress.XtraEditors.TextEdit TxtÜrünAdıAra;
        private DevExpress.XtraEditors.LabelControl labelControl26;
        private DevExpress.XtraEditors.SimpleButton simpleButton6;
    }
}