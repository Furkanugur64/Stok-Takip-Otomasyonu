﻿
namespace UĞUR_PAZARLAMA
{
    partial class FrmGirisYap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmGirisYap));
            this.TxtKullaniciadi = new DevExpress.XtraEditors.TextEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.TxtSifre = new DevExpress.XtraEditors.TextEdit();
            this.pictureEdit1 = new DevExpress.XtraEditors.PictureEdit();
            this.BtnGirisYap = new DevExpress.XtraEditors.SimpleButton();
            this.BtnCikisYap = new DevExpress.XtraEditors.SimpleButton();
            this.PInsta = new DevExpress.XtraEditors.PictureEdit();
            this.PFace = new DevExpress.XtraEditors.PictureEdit();
            this.PLinkedin = new DevExpress.XtraEditors.PictureEdit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtKullaniciadi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtSifre.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PInsta.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PFace.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PLinkedin.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // TxtKullaniciadi
            // 
            this.TxtKullaniciadi.Location = new System.Drawing.Point(120, 144);
            this.TxtKullaniciadi.Name = "TxtKullaniciadi";
            this.TxtKullaniciadi.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.TxtKullaniciadi.Properties.Appearance.Options.UseFont = true;
            this.TxtKullaniciadi.Properties.MaxLength = 11;
            this.TxtKullaniciadi.Size = new System.Drawing.Size(133, 26);
            this.TxtKullaniciadi.TabIndex = 0;
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.White;
            this.labelControl1.Appearance.Options.UseFont = true;
            this.labelControl1.Appearance.Options.UseForeColor = true;
            this.labelControl1.Location = new System.Drawing.Point(21, 147);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(93, 19);
            this.labelControl1.TabIndex = 1;
            this.labelControl1.Text = "Kullanıcı Adı:";
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelControl2.Appearance.ForeColor = System.Drawing.Color.White;
            this.labelControl2.Appearance.Options.UseFont = true;
            this.labelControl2.Appearance.Options.UseForeColor = true;
            this.labelControl2.Location = new System.Drawing.Point(76, 193);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(38, 19);
            this.labelControl2.TabIndex = 3;
            this.labelControl2.Text = "Şifre:";
            // 
            // TxtSifre
            // 
            this.TxtSifre.Location = new System.Drawing.Point(120, 190);
            this.TxtSifre.Name = "TxtSifre";
            this.TxtSifre.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.TxtSifre.Properties.Appearance.Options.UseFont = true;
            this.TxtSifre.Properties.PasswordChar = '*';
            this.TxtSifre.Size = new System.Drawing.Size(133, 26);
            this.TxtSifre.TabIndex = 2;
            // 
            // pictureEdit1
            // 
            this.pictureEdit1.EditValue = ((object)(resources.GetObject("pictureEdit1.EditValue")));
            this.pictureEdit1.Location = new System.Drawing.Point(82, 12);
            this.pictureEdit1.Name = "pictureEdit1";
            this.pictureEdit1.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.pictureEdit1.Properties.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Stretch;
            this.pictureEdit1.Size = new System.Drawing.Size(194, 101);
            this.pictureEdit1.TabIndex = 4;
            // 
            // BtnGirisYap
            // 
            this.BtnGirisYap.Appearance.BackColor = System.Drawing.Color.Green;
            this.BtnGirisYap.Appearance.BorderColor = System.Drawing.Color.White;
            this.BtnGirisYap.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnGirisYap.Appearance.ForeColor = System.Drawing.Color.White;
            this.BtnGirisYap.Appearance.Options.UseBackColor = true;
            this.BtnGirisYap.Appearance.Options.UseBorderColor = true;
            this.BtnGirisYap.Appearance.Options.UseFont = true;
            this.BtnGirisYap.Appearance.Options.UseForeColor = true;
            this.BtnGirisYap.Location = new System.Drawing.Point(21, 241);
            this.BtnGirisYap.Name = "BtnGirisYap";
            this.BtnGirisYap.Size = new System.Drawing.Size(149, 61);
            this.BtnGirisYap.TabIndex = 5;
            this.BtnGirisYap.Text = "Giriş Yap";
            this.BtnGirisYap.Click += new System.EventHandler(this.BtnGirisYap_Click);
            // 
            // BtnCikisYap
            // 
            this.BtnCikisYap.Appearance.BackColor = System.Drawing.Color.Red;
            this.BtnCikisYap.Appearance.BorderColor = System.Drawing.Color.White;
            this.BtnCikisYap.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnCikisYap.Appearance.ForeColor = System.Drawing.Color.White;
            this.BtnCikisYap.Appearance.Options.UseBackColor = true;
            this.BtnCikisYap.Appearance.Options.UseBorderColor = true;
            this.BtnCikisYap.Appearance.Options.UseFont = true;
            this.BtnCikisYap.Appearance.Options.UseForeColor = true;
            this.BtnCikisYap.Location = new System.Drawing.Point(185, 241);
            this.BtnCikisYap.Name = "BtnCikisYap";
            this.BtnCikisYap.Size = new System.Drawing.Size(120, 61);
            this.BtnCikisYap.TabIndex = 6;
            this.BtnCikisYap.Text = "Çıkış";
            this.BtnCikisYap.Click += new System.EventHandler(this.BtnCikisYap_Click);
            // 
            // PInsta
            // 
            this.PInsta.EditValue = ((object)(resources.GetObject("PInsta.EditValue")));
            this.PInsta.Location = new System.Drawing.Point(40, 328);
            this.PInsta.Name = "PInsta";
            this.PInsta.Properties.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.PInsta.Properties.Appearance.Options.UseBackColor = true;
            this.PInsta.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.PInsta.Properties.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Stretch;
            this.PInsta.Size = new System.Drawing.Size(50, 50);
            this.PInsta.TabIndex = 7;
            this.PInsta.Click += new System.EventHandler(this.PInsta_Click);
            // 
            // PFace
            // 
            this.PFace.EditValue = ((object)(resources.GetObject("PFace.EditValue")));
            this.PFace.Location = new System.Drawing.Point(120, 328);
            this.PFace.Name = "PFace";
            this.PFace.Properties.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.PFace.Properties.Appearance.Options.UseBackColor = true;
            this.PFace.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.PFace.Properties.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Stretch;
            this.PFace.Size = new System.Drawing.Size(50, 50);
            this.PFace.TabIndex = 8;
            this.PFace.Click += new System.EventHandler(this.PFace_Click);
            // 
            // PLinkedin
            // 
            this.PLinkedin.EditValue = ((object)(resources.GetObject("PLinkedin.EditValue")));
            this.PLinkedin.Location = new System.Drawing.Point(203, 328);
            this.PLinkedin.Name = "PLinkedin";
            this.PLinkedin.Properties.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.PLinkedin.Properties.Appearance.Options.UseBackColor = true;
            this.PLinkedin.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.PLinkedin.Properties.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Stretch;
            this.PLinkedin.Size = new System.Drawing.Size(50, 50);
            this.PLinkedin.TabIndex = 9;
            this.PLinkedin.Click += new System.EventHandler(this.PLinkedin_Click);
            // 
            // FrmGirisYap
            // 
            this.Appearance.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.Appearance.Options.UseBackColor = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(346, 404);
            this.Controls.Add(this.PLinkedin);
            this.Controls.Add(this.PFace);
            this.Controls.Add(this.PInsta);
            this.Controls.Add(this.BtnCikisYap);
            this.Controls.Add(this.BtnGirisYap);
            this.Controls.Add(this.pictureEdit1);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.TxtSifre);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.TxtKullaniciadi);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmGirisYap";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmGirisYap";
            this.Load += new System.EventHandler(this.FrmGirisYap_Load);
            ((System.ComponentModel.ISupportInitialize)(this.TxtKullaniciadi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TxtSifre.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PInsta.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PFace.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PLinkedin.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.TextEdit TxtKullaniciadi;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.TextEdit TxtSifre;
        private DevExpress.XtraEditors.PictureEdit pictureEdit1;
        private DevExpress.XtraEditors.SimpleButton BtnGirisYap;
        private DevExpress.XtraEditors.SimpleButton BtnCikisYap;
        private DevExpress.XtraEditors.PictureEdit PInsta;
        private DevExpress.XtraEditors.PictureEdit PFace;
        private DevExpress.XtraEditors.PictureEdit PLinkedin;
    }
}